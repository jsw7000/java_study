

import java.util.Arrays;

public class ProductMgr {

	private ProductMgr() {
	}

	private static ProductMgr instance;

	public static ProductMgr getInstance() {
		if (instance == null)
			instance = new ProductMgr();
		return instance;
	}

	private Product[] prod = new Product[100];
	private static int count = 0;

	// 상품저장
	public void add(Product p) {
		prod[count] = p;
		count++;
	}

	// 저장된 상품List검색
	public Product[] list() {
		Product[] save = new Product[count];
		for(int i=0;i<count;i++){
				save[i]=prod[i];
		}
		return save;
	}

	// 상품 번호로 검색
	public Product list(int num) {
		for(int i=0;i<count;i++) {
			if(prod[i].getPnum()==num)
				return prod[i];
		}
		return null;
	}

	// 상품 번호로 삭제
	public void delete(int num) {
		for(int i=0;i<count;i++) {
			if(prod[i].getPnum()==num) {
				prod[i]=prod[count-1];
				prod[count-1]=null;
				count--;
			}
		}
	}

	// 특정가격 이하의 상품만 검색..애매모호ㅜ
	public Product[] priceList(int price) {
		Product[] specific = new Product[count];
		int pcount=0;
		for(int i=0;i<count;i++) {
			if(prod[i].getPrice()<price) {
				specific[pcount]= prod[i];
				pcount++;
			}
		}
		return Arrays.copyOfRange(specific,0,pcount);
	}

}
