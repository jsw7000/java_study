package HW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

public class SWEA_하나로 {
	static class Node implements Comparable<Node> {
		int no;
		long weight;

		public Node(int no, long weight) {
			super();
			this.no = no;
			this.weight = weight;

		}

		@Override
		public int compareTo(Node o) {
			return Long.compare(this.weight, o.weight);
		}

	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int T = Integer.parseInt(br.readLine());
		for (int tc = 1; tc <= T; tc++) {
			int N = Integer.parseInt(br.readLine());
			int[][] map = new int[N][2];
			boolean[] visited = new boolean[N];
			StringTokenizer st = new StringTokenizer(br.readLine(), " ");
			for (int i = 0; i < N; i++) {
				int x = Integer.parseInt(st.nextToken());
				map[i][0] = x;
			}
			st = new StringTokenizer(br.readLine(), " ");
			for (int i = 0; i < N; i++) {
				int y = Integer.parseInt(st.nextToken());
				map[i][1] = y;
			}

			ArrayList<Node>[] adj = new ArrayList[N];
			for (int i = 0; i < N; i++) {
				adj[i] = new ArrayList<>();
				for (int j = 0; j < N; j++) {
					long distanceX = map[i][0]-map[j][0];
					long distanceY = map[i][1]-map[j][1];;

					adj[i].add(new Node(j, distanceX * distanceX + distanceY * distanceY));
				}
			}
			double E = Double.parseDouble(br.readLine());

			long result = 0;
			int nodeCnt = 0;
			PriorityQueue<Node> queue = new PriorityQueue<>();
			queue.add(new Node(0, 0));

			while (!queue.isEmpty()) {
				Node now = queue.poll();

				if (visited[now.no])
					continue;

				result += now.weight;
				visited[now.no] = true;

				if (++nodeCnt == N)
					break;

				for (int i = 0; i < adj[now.no].size(); i++) {
					Node next = adj[now.no].get(i);
					if (!visited[next.no]) {
						queue.add(next);
					}
				}

			}
			double money = E * result;
			System.out.println("#" + tc + " " + Math.round(money));

		}
	}

}
