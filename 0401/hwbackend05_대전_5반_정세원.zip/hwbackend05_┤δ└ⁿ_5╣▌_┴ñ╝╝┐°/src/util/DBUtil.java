package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	static final String url = "jdbc:mysql://127.0.0.1:3306/ssafyweb?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
	static final String Driver = "com.mysql.cj.jdbc.Driver";
	static final String userId = "ssafy";
	static final String userPw = "ssafy";
	
	static {
		try {
			Class.forName(Driver);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(url, userId, userPw);
	}
	
	public static void close(AutoCloseable... closeables) {
		for(AutoCloseable c : closeables) {
			if(c!=null) {
				try {
					c.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	
}
