package HW;

import java.util.Scanner;

public class SpotMart {
	static int[] weight;
	static int[] result;
	static int N,M;
	static int R=2;
	static int[] max;
	static int sum_weight=0;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		max = new int[T+1];
		for(int tc=1;tc<=T;tc++) {
			N=sc.nextInt(); //과장봉지 개수
			M = sc.nextInt(); // 과자 두 봉지의 무게
			weight = new int[N];
			result = new int[R];
			//과자봉지 두개만 들면됨
			max[tc] = -1;
			for(int i=0;i<N;i++) {
				weight[i] = sc.nextInt();
			}			
			
			comb(0,0,0,tc);
			
			System.out.println("#"+tc+" "+max[tc]);
			
		}
	}
	static void comb(int start,int cnt,int sum,int test_case) {
		if(cnt==R) {
			if(sum<=M)
				max[test_case]=max[test_case]<sum?sum:max[test_case];
			else return;
			return;
		}
		for(int i=start;i<N;i++) {
			comb(i+1,cnt+1,sum+weight[i],test_case);
		}
	}

}
