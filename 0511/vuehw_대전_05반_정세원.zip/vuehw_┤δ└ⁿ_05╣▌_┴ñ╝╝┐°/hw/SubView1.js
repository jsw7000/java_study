export default { //자식 컴포넌트 입니다.
    props:['bus'],
    template: `
    <div>
    <table border="1">
      <tr>
        <th>글번호</th>
        <th>제목</th>
        <th>작성자</th>
      </tr>
      <tr v-for="bbb in mydata.bList">
        <td v-text="bbb.bnum"></td>

        <td><a href='javascript:void(0);' v-on:click="read(bbb.bnum)">{{bbb.btitle}}</a></td>
        <td v-text="bbb.bwriter"></td>
      </tr>
    </table>
  </div>
  `,
    data() {
        return {
          mydata: "",
          result:"",
        }
    },
  created() {
    axios
      .get("http://182.224.88.49:9999/bootboard/boardMain") 
      .then((resp) => {
        console.log(resp);
        this.mydata = resp.data;
      });
  },
  methods: {
    read(num) {
      this.bus.$emit('read', num);
    }
  },
}