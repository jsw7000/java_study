package com.ssafy.board.repository;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.board.Mapper.CommentMapper;
import com.ssafy.board.dto.CommentDto;

// comment_tb 테이블에 디비 sql 작업하는 클래스
@Repository
public class CommentDao {
	@Autowired
	private SqlSessionTemplate template;
	
	// 댓글 작성
	public int insert(CommentDto commentDto) {
		return template.getMapper(CommentMapper.class).insert(commentDto);
		
	}
	
	// 게시글 내용 읽기 화면에서 댓글 달린것들 보여줄 때
	public List<CommentDto> selectList(int bnum){
		return template.getMapper(CommentMapper.class).selectList(bnum);
		
	}
	
	// 게시글들에 댓글 몇개씩 달려있는지 버블
	public int selectCommentCount(int bnum) {
		return template.getMapper(CommentMapper.class).selectCommentCount(bnum);
		
	}

//	public int delete(int bnum) {
//		return template.getMapper(CommentMapper.class).delete(bnum);
//	}
}
