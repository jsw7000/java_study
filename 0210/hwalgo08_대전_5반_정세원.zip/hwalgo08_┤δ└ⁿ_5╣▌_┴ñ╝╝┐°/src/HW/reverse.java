package HW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class reverse {

	public static void main(String[] args) throws IOException {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringBuilder sb = new StringBuilder();
		StringTokenizer st = new StringTokenizer(br.readLine()," ");
		
		while(st.hasMoreTokens()) {
			String str = st.nextToken();
			for(int i=str.length()-1;i>=0;i--)
				if(str.contains("<"));
			str.
				sb.append(str.charAt(i));
			sb.append(" ");
		}
		sb.setLength(sb.length()-1);;
	}

}
