/**
 * 
 */
$(function(){
	
$('.login').click(function(){
		$('#myModal').show();
	});
	
	$('.close,.close-btn').click(function(){
		$('#myModal').hide();
	});
	
	$('.login-btn').click(function(){
		let input_id=$('#login_id').val();
		let input_pwd=$('#login_pwd').val();
		$.ajax({
			url: 'userlist.xml',
			type:'GET',
			dataType:'xml',
			success:function(data){
				modal_login(data);
			},
			error: function(){ // 로딩 에러시
				alert('Error loading XML document'); 
				}
		});
		
		function modal_login(data){
			$(data).find('user').each(function(){
				let tmp_id = $(this).find('id').text();
				let tmp_pwd =$(this).find('password').text();
				
				if(input_id==tmp_id){
					if(input_pwd==tmp_pwd){
						//로그인 성공->로그인 성공 화면으로 넘어가기
						$('.before_login').css('display','none');
						$('.after_login').css('display','');
						$('.success-id').append(input_id);
						$('#myModal').hide();
					}else{
						alert('비밀번호가 틀립니다.');
					}
				}
			})
		}
	});
	$('.logout').click(function(){
		$.ajax({
			success:function(){
				$('.after_login').css('display','none');
				$('.before_login').css('display','');
			}
		})
	})
	
//	글쓰기 화면 전환
	$('#write-list-btn').click(function(){
		$('#text-write').css('display','none');
		$('.text-list').css('display', '');
	})
	
	$('#reset-btn').click(function(){
		$('#write-title,#textarea').val('');
	})
	
	$('#text-list-write').click(function(){
		$('#text-write').css('display','');
		$('.text-list').css('display', 'none');
	})
	
	//게시글보기
	$('.text-list-table tbody>tr').click(function(){
		$('.text-read').css('display','');
		$('.text-list').css('display', 'none');
	})
})