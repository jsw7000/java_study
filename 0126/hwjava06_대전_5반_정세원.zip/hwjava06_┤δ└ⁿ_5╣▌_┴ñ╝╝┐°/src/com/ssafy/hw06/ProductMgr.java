package com.ssafy.hw06;

public class ProductMgr {

	private ProductMgr() {
	}

	private static ProductMgr instance;

	public static ProductMgr getInstance() {
		if (instance == null)
			instance = new ProductMgr();
		return instance;
	}
	//상품정보(TV/냉장고)를 객체 배열을 활용하여 저장
	//상품정보 전체를 검색
	//상품번호로 상품 검색
	// 상품명으로 상품 검색(상품명 부분 검색 가능)
	// TV정보만 검색
	//Refrigerator 검색
	//상품번호로 상품을 삭제
	//전체 재고 상품 금액을 구하는 기능
	private Product[] prod=new Product[100];
	private static int count = 0;

	// 상품저장
	public void add(Product p) {
		prod[count]=p;
		count++;
	}

	// 저장된 상품List검색
	public Product[] list() {
		Product[] save = new Product[count];
		for(int i=0;i<count;i++){
				save[i]=prod[i];
		}
		return save;
	}

	// 상품 번호로 검색
	public Product list(int num) {
		for(int i=0;i<count;i++) {
			if(prod[i].getPnum()==num)
				return prod[i];
		}
		return null;
	}

	// 상품 번호로 삭제
	public void delete(int num) {
		for(int i=0;i<count;i++) {
			if(prod[i].getPnum()==num) {
				prod[i]=prod[count-1];
				prod[count-1]=null;
				count--;
			}
		}
	}


	public Product[] searchName(String name) {
		int cnt = 0; 
		for (int i = 0; i < count; ++i) {	// 도서 제목을 포함하는 도서의 개수 카운트
			if (prod[i].getPname().contains(name)) ++cnt;
		}
		Product[] result = new Product[cnt];	// 결과 카운트만큼 배열 생성
		int idx = 0;
		for (int i = 0; i < count; ++i) {
			if (prod[i].getPname().contains(name)) { // 도서 제목을 포함하는 도서만 배열에 담기
				result[idx++] = prod[i];
			}
		}
		return result; 
	}


	public TV[] getTV() {
		int cnt = 0;
		for (int i = 0; i < count; ++i) {	// 잡지 개수 카운트
			if (prod[i] instanceof TV) ++cnt;
		}
		TV[] result = new TV[cnt];	// 결과 카운트만큼 배열 생성
		int idx = 0;
		for (int i = 0; i < count; ++i) {
			if (prod[i] instanceof TV) {	// 잡지만 배열에 담기
				result[idx++] = (TV)prod[i];
			}
		}
		return result;
	} 
	
	public Refrigerator[] getRefrigerator() {
		int cnt = 0;
		for (int i = 0; i < count; ++i) {	// 잡지 개수 카운트
			if (prod[i] instanceof Refrigerator) ++cnt;
		}
		Refrigerator[] result = new Refrigerator[cnt];	// 결과 카운트만큼 배열 생성
		int idx = 0;
		for (int i = 0; i < count; ++i) {
			if (prod[i] instanceof Refrigerator) {	// 잡지만 배열에 담기
				result[idx++] = (Refrigerator)prod[i];
			}
		}
		return result;
	} 
	
	public int getTotalPrice() {
		int total=0;
		for(int i=0;i<count;i++) {
			total = total+ prod[i].getPrice();
		}
		return total;
	}
	

}
