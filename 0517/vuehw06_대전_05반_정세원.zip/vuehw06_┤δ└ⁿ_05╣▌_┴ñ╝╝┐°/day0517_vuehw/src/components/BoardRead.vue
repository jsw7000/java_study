<template>
  <div>
    <table border="1">
      <tr>
        <td>제목</td>
        <td>{{ board.btitle }}</td>
      </tr>
      <tr>
        <td>작성자</td>
        <td>{{ board.bwriter }}</td>
      </tr>
      <tr>
        <td>작성일</td>
        <td>{{ getFormatDate(board.bregdate) }}</td>
      </tr>
      <tr>
        <td>내용</td>
        <td>{{ board.bcontent }}</td>
      </tr>
    </table>
    <router-link :to="`/board/modify?bnum=${board.bnum}`">수정하기</router-link>|
    <router-link :to="`/board/delete?bnum=${board.bnum}`">삭제하기</router-link>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import moment from "moment";
export default {
  computed: {
    ...mapGetters(["board"]),
  },
  created() {
    let bnum = this.$route.query.bnum;
    console.log(bnum);
    // http.get(`/board?bnum=${bnum}`)
    // .then((resp)=>{
    //     this.article = resp.data;
    //     // console.log(list);
    // })
    this.$store.dispatch("getBoard", { bnum });
  },
  methods: {
    getFormatDate(regdate) {
      return moment(new Date(regdate)).format("YY.MM.DD HH:mm:ss");
    },
  },
};
</script>
