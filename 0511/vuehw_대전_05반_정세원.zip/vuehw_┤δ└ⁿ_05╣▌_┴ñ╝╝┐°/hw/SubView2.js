export default {
    template: `
    <div>
    <table border="1" >
      <tr>
        <td>글번호</td>
        <td>{{mydata.bnum}}</td>
        <td>제목</td>
        <td>{{mydata.btitle}}</td>
      </tr>
      <tr>
        <td>작성자</td>
        <td colspan="3">{{mydata.bwriter}}</td>
      </tr>
      <tr>
        <td>내용</td>
        <td colspan="3">{{mydata.bcontent}}</td>
      </tr>
    </table>
    </div>`,
    data() {
        return {
            mydata:"",
        }
    },
    created() {
      this.bus.$on('read', this.okay);
    },
    props: ['bus'],
    methods: {
      okay(receive) {
        axios
            .get(`http://182.224.88.49:9999/bootboard/board?bnum=${receive}`)
            .then((resp) => {
              this.mydata = resp.data;
              console.log(this.mydata.btitle);
        })

      }
    },
}