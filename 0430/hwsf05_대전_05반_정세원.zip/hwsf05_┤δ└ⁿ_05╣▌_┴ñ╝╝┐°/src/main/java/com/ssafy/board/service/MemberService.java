package com.ssafy.board.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.board.dto.MemberDto;
import com.ssafy.board.repository.MemberDao;

@Service
public class MemberService {
	
	@Autowired
	private MemberDao mdao;
	
	public MemberDto login(String userid,String userpwd) throws SQLException,Exception {
		return mdao.login(userid, userpwd);
	}

	
}
