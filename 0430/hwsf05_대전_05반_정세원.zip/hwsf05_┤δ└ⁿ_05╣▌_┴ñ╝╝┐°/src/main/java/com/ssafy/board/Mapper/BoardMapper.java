package com.ssafy.board.Mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ssafy.board.dto.BoardDto;

public interface BoardMapper {
	public int insert(BoardDto boardDto);
	public BoardDto selectOne(int bnum);
	public List<BoardDto> selectList(@Param("startRow") int startRow,@Param("count") int count);
	public int selectTotalCount();
	public int delete(int bnum);
	public int update(BoardDto boardDto);
	public List<BoardDto> makeSearchPage(@Param("select")String select,@Param("search") String search);
}
