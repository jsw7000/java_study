package com.ssafy.rest.model.dao;

import java.sql.SQLException;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.rest.model.dto.Product;
import com.ssafy.rest.model.mapper.ProductMapper;



@Repository
public class ProductDao{
	@Autowired
	private SqlSessionTemplate template;
	public int insert(Product product) throws SQLException {
		return template.getMapper(ProductMapper.class).insert(product);
	}

	public Product select(String pCode) throws SQLException {
		return template.getMapper(ProductMapper.class).select(pCode);
	}

	public List<Product> selectAll() throws SQLException {
		return template.getMapper(ProductMapper.class).selectAll();
	}

}
