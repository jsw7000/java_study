package HW;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Refrigerator {

	public static class Chemical implements Comparable<Chemical> {

		int low;
		int high;

		public Chemical(int low, int high) {
			super();
			this.low = low;
			this.high = high;
		}

		@Override
		public int compareTo(Chemical o) {
			int dif = this.high - o.high;
			return dif != 0 ? dif : this.low - o.low;
		}

	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();

		Chemical[] ch = new Chemical[N];

		for (int i = 0; i < N; i++) {
			ch[i] = new Chemical(sc.nextInt(), sc.nextInt());
		}

		Arrays.sort(ch);

		/*
		 * 정렬했쥐? 우선 그냥 for문 돌려 리스트에 냉장고 클래스를 만들어서 넣는다. 리스트 사이즈만큼 for문 돌려서 냉장고 클래스의
		 * low,high 변수의 범위와 비교하고자 하는 i번째 화학물질의 최저,최고온도와 겹치는지 비교! 겹치면 최저온도와 최고온도값 비교해서
		 * 재설정 안겹치면 그냥 냉장고 새로 만들기
		 */

		ArrayList<Chemical> list = new ArrayList<>();
		Chemical tmp = new Chemical(ch[0].low, ch[0].high);
		list.add(tmp);
		for (int i = 1; i < N; i++) {
			if (list.get(list.size() - 1).high >= ch[i].low) {
				continue;
			} else {
				Chemical temp = new Chemical(ch[i].low, ch[i].high);
				list.add(temp);
			}

		}

		System.out.println(list.size());

	}

}
