package model.dao;

import java.util.List;

import model.GuestBookDto;

public interface GuestBookDao {
	List<GuestBookDto> listArticle(String key, String word) throws Exception;
	
	void writeArticle(GuestBookDto guestBookDto) throws Exception;
}
