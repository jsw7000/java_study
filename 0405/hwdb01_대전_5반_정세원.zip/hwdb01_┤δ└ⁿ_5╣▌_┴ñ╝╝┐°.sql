create schema hw;
use hw;
select @@autocommit;

-- 1
drop table if exists product;
create table product(
	code varchar(30),
    name varchar(100),
    price int,
	PRIMARY KEY (code)
);
-- 2
insert into hw.product (code,name,price)
values ('1234','S TV',1500000),
('2345','울트라 노트북',1000000),
('3456','S 노트북',800000),
('4567','L TV',1200000),
('5678','슈퍼 TV',2000000);

select *
from product;

-- 3
select code,name,price*0.85 as price
from product;

-- 4
update product
set price=price*0.8
where name like '%TV%';

-- 5
select sum(price)
from product;
