package HW;

import java.util.Scanner;

public class 백준2564_경비원 {
	static int Height,Length,N;
	static int[] store;
	static int dg;
	public static void main(String[] args) {
		/*
		 * 동근이의 위치가 주어질 때 동근이의 위치와 각 상점 사이의 최단 거리의 합을 구하라
		 * 
		 * bfs,다익스트라?
		 * int hegith,legnth;
		 * 상점갯수 N
		 * 상점의 위치는 Node class 선언해서 list에 넣기
		 * 
		 * 첫번째 수 1 : 북쪽, 2 : 남쪽, 3:서쪽,4:동쪽 상하좌우
		 * 두번째 수 북쪽/남쪽 : 왼쪽경계로부터의 거리, 서쪽/동쪽 : 위쪽 경계로부터의 거리
		 * 마지막줄은 동근이 위치!
		 * 상점의 위치나 동근이의 위치는 블록의 꼭짓점이 될 수 없다!
		 * */
		
		//삼각형을 끊어서 선처럼 펼쳐라..?
		//만약 북쪽이면 왼쪽경계로부터의 거리만, 동쪽이면 length+위쪽으로의 거리
		// 남쪽이면 가로길이+세로길이+오른쪽으로의 거리, 서쪽이면 가로*2+세로길이 + 아래쪽으로의 거리
		
		Scanner sc = new Scanner(System.in);
		Length = sc.nextInt();
		Height = sc.nextInt();
		N = sc.nextInt();
		store = new int[N];
		
		for(int i=0;i<N;i++) {
			int d= sc.nextInt();
			int l= sc.nextInt();
//			if(d==1) {//북
//				store[i]=l;
//			}else if(d==4) {//동
//				store[i]=Length+l;
//			}else if(d==2) {//남
//				store[i]=Length+Height+(Length-l);
//			}else if(d==3) {//서
//				store[i]=(Length*2)+Height+(Height-l);
//			}
			store[i]=calculate(d, l);
		}
		
		dg = calculate(sc.nextInt(), sc.nextInt());
		
		int sum=0;
		
		for(int i=0;i<N;i++) {
			//중간값으로 비교하는게 더 가까운지
			int inner = Math.abs(dg-store[i]);
			//outer로 비교하는게 가까운지
			int outer=0;
			int total = Length*2+Height*2;
			if(store[i]>dg) {
				int cal_st=total-store[i];
				outer = dg+cal_st;
			}else if(store[i]<dg) {
				int cal_dg = total-dg;
				outer=cal_dg+store[i];
			}
			sum+=inner<outer?inner:outer;
		
		}
		
		System.out.println(sum);
	}
	public static int calculate(int d,int l) {
		int result=0;
		if(d==1) {//북
			result=l;
		}else if(d==4) {//동
			result=Length+l;
		}else if(d==2) {//남
			result=Length+Height+(Length-l);
		}else if(d==3) {//서
			result=(Length*2)+Height+(Height-l);
		}
		
		return result;
	}

}
