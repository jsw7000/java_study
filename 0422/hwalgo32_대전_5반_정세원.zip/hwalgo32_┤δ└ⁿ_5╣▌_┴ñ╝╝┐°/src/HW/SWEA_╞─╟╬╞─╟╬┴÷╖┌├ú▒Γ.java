package HW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;

import HW.SWEA_파핑파핑지뢰찾기.Point;

public class SWEA_파핑파핑지뢰찾기 {
	static int N;
	static int[] dx = { -1, -1, -1, 0, 1, 1, 1, 0 }; // 왼쪽 꼭짓점부터 시계방향
	static int[] dy = { -1, 0, 1, 1, 1, 0, -1, -1 };
	static boolean[][] visit;
	static char[][] map;

	static class Point {
		int x, y;

		public Point(int x, int y) {
			super();
			this.x = x;
			this.y = y;
		}

	}

	static ArrayList<Point> list = new ArrayList<>();

	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int T = Integer.parseInt(br.readLine());
		for (int tc = 1; tc <= T; tc++) {
			N = Integer.parseInt(br.readLine());
			map = new char[N][N];
			visit = new boolean[N][N];
			for(int i=0;i<N;i++) {
				String str = br.readLine();
				for(int j=0;j<N;j++) {
					map[i][j]=str.charAt(j);
				}
			}
			int ans = 0;
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					if (map[i][j] != '.')
						continue;
					if (count(i, j) == 0) {
						ans++;
						dfs(i, j);
					}
				}
			}
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					if (map[i][j] == '.')
						ans++;
				}
			}
			System.out.println("#" + tc + " " + ans);

		}
	}

	private static void dfs(int row, int col) {
		visit[row][col] = true;
		int mine = count(row, col);
		map[row][col] = (char) (mine + '0');
		if (map[row][col] != '0')
			return;
		for (int d = 0; d < 8; d++) {
			int nx = row + dx[d];
			int ny = col + dy[d];
			if (0 <= nx && nx < N && 0 <= ny && ny < N && map[nx][ny] == '.' && !visit[nx][ny])
				dfs(nx, ny);
		}
	}

	private static int count(int row, int col) {
		int mine = 0;
		for (int d = 0; d < 8; d++) {
			int nx = row + dx[d];
			int ny = col + dy[d];
			if (0 <= nx && nx < N && 0 <= ny && ny < N && map[nx][ny] == '*')
				mine++;
		}
		return mine;
	}

}
