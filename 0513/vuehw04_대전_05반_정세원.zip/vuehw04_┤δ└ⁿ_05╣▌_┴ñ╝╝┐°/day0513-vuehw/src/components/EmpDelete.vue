<template>
    <div>
        <h3>삭제 결과 : {{result}}</h3>
        <router-link to="/emplist">사원목록보기</router-link>
    </div>
</template>
<script>
import http from '@/util/http-common';
export default {
    name:'delete',
    data() {
        return {
            result: '',
            id:'',
        }
    },
    created(){
        this.id = this.$route.query.id;
        console.log(this.id);
        http.delete(`/employee?id=${this.id}`)
        .then((resp)=>{
            this.result=resp.data;
            console.log(this.result);
        })
    }
}
</script>