create schema ssafy_company;
use ssafy_company;

DROP TABLE IF EXISTS employees;
CREATE TABLE IF NOT EXISTS employees(
	id int primary key auto_increment,
	name varchar(16) not null,
	deptName varchar(16),
	title varchar(16) default("사원"),
	salary int default(600)
);



select * from employees;
insert into employees(name,deptName,title,salary) values("박구곤","인사부","사장",60000),("서정주","기획부","사원",13000),("안창환","기획부","사원",678),("윤정숙","기획부","사원",750),("장취산","영업부","사원",23244),("조현욱","회계부","사원",1500);

commit;