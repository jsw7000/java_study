package com.ssafy.board.Mapper;

import java.util.List;

import com.ssafy.board.dto.CommentDto;

public interface CommentMapper {

	public int insert(CommentDto commentDto);
	public List<CommentDto> selectList(int bnum);
	public int selectCommentCount(int bnum);
	
	
}
