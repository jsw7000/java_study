<template>
  <div>
    <!-- <BoardList /> -->
    <!-- <router-link to="/board/list">목록</router-link> -->
    <router-view></router-view>
  </div>
</template>
<script>
// import BoardList from "@/components/BoardList.vue";
export default {
  name: "board",
  components: {
    // BoardList,
  },
};
</script>
<style></style>
