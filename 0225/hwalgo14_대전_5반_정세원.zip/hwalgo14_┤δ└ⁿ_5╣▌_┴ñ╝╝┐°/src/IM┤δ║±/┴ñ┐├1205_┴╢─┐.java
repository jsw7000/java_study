package IM대비;

import java.util.Arrays;
import java.util.Scanner;

public class 정올1205_조커 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		int[] card = new int[N];
		int cnt = 0;

		for (int i = 0; i < N; i++) {
			card[i] = sc.nextInt();
			if (card[i] == 0)
				cnt++;
		}

		Arrays.sort(card);

//		System.out.println(Arrays.toString(card));

		int len = 1;
		int i = 0;
		if (cnt != 0)
			i = cnt;
		
		int max = 0;
		for (; i < N; i++) {
			if (i + 1 >= N) {
				max = max < len ? len : max;
				break;
			}
			if (card[i] + 1 == card[i + 1]) {
				len++;
				continue;
			} else if (card[i] == card[i + 1]) {
				continue;
			} else if (card[i + 1] - card[i] - 1 <= cnt) {
				len += card[i + 1] - card[i];
				cnt = cnt- (card[i + 1] - card[i] - 1);
				continue;
			}
			max = max < len ? len : max;
			len = 1;
			// 그리고 중간에 숫자가 끊겼을 때는??

		}

		System.out.print(max + cnt);

	}

}
