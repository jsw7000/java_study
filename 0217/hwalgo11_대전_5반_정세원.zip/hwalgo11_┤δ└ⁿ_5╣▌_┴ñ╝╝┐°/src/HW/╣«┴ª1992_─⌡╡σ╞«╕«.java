package HW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class 문제1992_쿼드트리 {
	static int N;
	static int[][] arr;
	static ArrayList<Character> list = new ArrayList<>();
	static StringBuilder sb = new StringBuilder();

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		N = Integer.parseInt(br.readLine());
		arr = new int[N][N];

		for (int i = 0; i < N; i++) {
			String str = br.readLine();
			System.out.println(str);
			int k = 0;
			for (int j = 0; j < N; j++) {
				arr[i][j] = Integer.valueOf(str.substring(k, k + 1));
				k++;
			}
		}

		partition(0, 0, N, N);
		System.out.println(sb);

	}

	public static void partition(int si, int sj, int ei, int ej) {

		if (ei - si == 1) {
			sb.append(arr[si][sj]);
			return;
		}
		if (equal(si, sj, ei, ej)) {
			sb.append(arr[si][sj]);
		} else {
			int mi = (si + ei) / 2;
			int mj = (si + ej) / 2;
			sb.append("(");
			partition(si, sj, mi, mj);
			partition(si, mj, mi, ej);
			partition(mi, sj, ei, mj);
			partition(mi, mj, ei, ej);
			sb.append(")");

		}

	}

	static boolean equal(int si, int sj, int ei, int ej) {
		int check = arr[si][sj];
		for (int i = si; i < ei; i++) {
			for (int j = sj; j < ej; j++) {
				if (check != arr[i][j]) {
					return false;
				}

			}
		}
		return true;
	}
}
