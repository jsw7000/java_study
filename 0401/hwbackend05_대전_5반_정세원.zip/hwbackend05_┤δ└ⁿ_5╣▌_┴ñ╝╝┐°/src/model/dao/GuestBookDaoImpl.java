package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.GuestBookDto;
import util.DBUtil;

public class GuestBookDaoImpl implements GuestBookDao{
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	@Override
	public void writeArticle(GuestBookDto guestBookDto) throws Exception {
		try {
			conn = DBUtil.getConnection();
			String sql = "insert into guestbook (userid,subject,content,regtime) " +
					" values(?,?,?,now())";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, guestBookDto.getUserid());
			pstmt.setString(2, guestBookDto.getSubject());
			pstmt.setString(3, guestBookDto.getContent());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			
		}
	}

	@Override
	public List<GuestBookDto> listArticle(String key, String word) throws Exception{
		List<GuestBookDto> list = new ArrayList<GuestBookDto>();
		try {
			conn = DBUtil.getConnection();
			String sql = "select articleno,userid,subject,content,regtime from guestbook";
			if(!word.isEmpty()) {
				if(key.equals("subject")) {
					sql += " where subject like ? ";
				}else {
					sql += " where "+ key+ "= ? ";
				}
			}
			sql += " order by articleno desc ";
			pstmt = conn.prepareStatement(sql);
			if(!word.isEmpty()) {
				if("subject".equals(key))
					pstmt.setString(1, "%" + word + "%");
				else
					pstmt.setString(1, word);
			}
			rs = pstmt.executeQuery();
			while(rs.next()) {
				GuestBookDto guestBookDto = new GuestBookDto();
				guestBookDto.setArticleno(rs.getInt("articleno"));
				guestBookDto.setUserid(rs.getString("userid"));
				guestBookDto.setSubject(rs.getString("subject"));
				guestBookDto.setContent(rs.getString("content"));
				guestBookDto.setRegtime(rs.getString("regtime"));
				
				list.add(guestBookDto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(conn,pstmt,rs);
		}
		return list;
	}


}
