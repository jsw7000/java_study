<template>
    <div>
        <h2>사원목록</h2>
        <table border="1">
        <tr>
            <td>사원번호</td>
            <td>이름</td>
            <td>부서</td>
            <td>직책</td>
            <td>연봉</td>
        </tr>
        <list-row v-for="(emp,index) in emps"
        :key="`${index}_emps`"
        :id="emp.id"
        :name="emp.name"
        :deptname="emp.deptname"
        :title="emp.title"
        :salary="emp.salary"
        />
        </table>
        <!-- <a href="./insert.html">사원 추가</a> -->
        <button @click="movePage">사원등록</button>
    </div>
</template>
<script>
import http from '../util/http-common.js';
import ListRow from './Row.vue';
export default {
    name : 'list',
    data() {
        return {
            emps:'',
        }
    },
    components:{
        ListRow,
    },
    created() {
        http
            .get("/employeeList")
            .then((resp) => {
                this.emps = resp.data;
                console.log(this.emps);
        })
        .catch(() => {
        alert('에러가 발생했습니다.');
      });
    },
    methods:{
        movePage(){
            this.$router.push('/empinsert');
        }
    }
};
</script>