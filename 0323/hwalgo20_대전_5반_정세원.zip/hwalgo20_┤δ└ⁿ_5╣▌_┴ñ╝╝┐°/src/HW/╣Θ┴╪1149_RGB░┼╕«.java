package HW;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
public class 백준1149_RGB거리 {
//	static int N;
//	static int[][] map;
//	static int[] result;
//	static int min = Integer.MAX_VALUE;
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int N = Integer.parseInt(br.readLine());
		int[][] map = new int[N+1][3];
//		result = new int[N];
		for(int i=1;i<=N;i++) {
			StringTokenizer st = new StringTokenizer(br.readLine()," ");
			int r=Integer.parseInt(st.nextToken());
			int g=Integer.parseInt(st.nextToken());
			int b=Integer.parseInt(st.nextToken());
			
			map[i][0]=r;
			map[i][1]=g;
			map[i][2]=b;
			
			
		}
		int[][] D = new int[N+1][3];
		for(int i=1;i<=N;i++) {
			D[i][0]=Math.min(D[i-1][1],D[i-1][2])+map[i][0];
			D[i][1]=Math.min(D[i-1][0],D[i-1][2])+map[i][1];
			D[i][2]=Math.min(D[i-1][0],D[i-1][1])+map[i][2];
		}
//		for(int i=0;i<3;i++) {
//			result[0]=i; // 0 : red, 1 : green, 2 : blue
//			dfs(i,1,map[0][i]);
//		}
		int min = Math.min(D[N][0], Math.min(D[N][1],D[N][2]));
		System.out.println(min);
	}
//	public static void dfs(int color,int cnt,int cost) {
//		if(cost>min) return;
//		
//		if(cnt==N) {
//			min=min>cost?cost:min;
//			return;
//		}
//		
//		int c = result[cnt-1];
//		for(int j=0;j<3;j++) {
//			if(c!=j) {
//				result[cnt]=j;
//				dfs(j,cnt+1,cost+map[cnt][j]);
//			}
//		}
//		
//	}

}
