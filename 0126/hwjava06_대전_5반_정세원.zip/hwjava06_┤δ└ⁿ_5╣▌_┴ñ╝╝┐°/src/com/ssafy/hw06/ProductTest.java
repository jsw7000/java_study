package com.ssafy.hw06;

import java.util.Scanner;

public class ProductTest {

	public static void main(String[] args) {

		ProductMgr pmgr = ProductMgr.getInstance();

		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("1:상품추가,2:상품목록,3:상품번호로 검색,4:상품명으로 검색,5:상품삭제,6:TV정보검색,7:냉장고정보검색,8:전체 재고 상품 금액,-1:프로그램종료");
			int select = sc.nextInt();
			if (select == -1) {
				System.out.println("프로그램을 종료합니다.");
				break;
			}

			switch (select) {
			case 1:
				System.out.println("추가하고자 하는 상품의 타입을 입력해주세요 (TV/Refrigerator): ");
				String type = sc.next();
				if (type.equals("TV")) {
					sc.nextLine();
					System.out.println("상품번호,상품이름,가격,수량,디스플레이,인치");
					String[] input = sc.nextLine().split(",");
					pmgr.add(new TV(Integer.parseInt(input[0]), input[1], Integer.parseInt(input[2]),
							Integer.parseInt(input[3]), input[4], Integer.parseInt(input[5])));
					System.out.println("상품 저장 완료");
				}else if(type.equals("Refrigerator")) {
					sc.nextLine();
					System.out.println("상품번호,상품이름,가격,수량,용량,에너지등급");
					String[] input = sc.nextLine().split(",");
					pmgr.add(new Refrigerator(Integer.parseInt(input[0]), input[1], Integer.parseInt(input[2]),
							Integer.parseInt(input[3]), input[4], Integer.parseInt(input[5])));
					System.out.println("상품 저장 완료");
				}else {
					System.err.println("잘못된 입력입니다.");
				}
				
				break;
			case 2:
				for (Product p : pmgr.list())
					System.out.println(p);
				break;
			case 3:
				int pnumber = sc.nextInt();
				System.out.println(pmgr.list(pnumber).toString());
				System.out.println("상품 검색 완료");
				break;
			case 4:
				String name = sc.next();
				for (Product p : pmgr.searchName(name))
					System.out.println(p);
				System.out.println("상품 검색 완료");
				break;
			case 5:
				int pRemove = sc.nextInt();
				pmgr.delete(pRemove);
				System.out.println("상품 삭제 완료");
				break;
			case 6:
				for(Product tv : pmgr.getTV()) {
					System.out.println(tv);
				}
				System.out.println("TV 검색 완료");
				break;
			case 7:
				for (Product ref : pmgr.getRefrigerator()) {
					System.out.println(ref);
				}
				System.out.println("냉장고 검색 완료");
				break;
			case 8:
				System.out.println("전체 재고 상품 금액 : " +pmgr.getTotalPrice());
				//전체 재고 상품 금액
				break;
			default:
				System.out.println("잘못된 입력입니다.");
			}

		}
		sc.close();
	}

}
