use world;

-- 1
select Code,Name
from country
where Code = (select CountryCode 
from city
where Name='kabul');

-- 2
select country.Name, lang.language,lang.percentage
from (select CountryCode as Code,language,percentage
from countrylanguage
where Percentage = 100 and isOfficial = 'T') as lang natural join country;

select *
from countrylanguage
where Percentage=100;

-- 3
select city.Name,cl.language,country.Name
from country join city
on city.CountryCode = country.Code
join countrylanguage as cl
on cl.CountryCode = country.Code
where cl.isofficial = 'T' and city.Name='amsterdam';

-- 4
select co.Name,Capital,ci.Name,ci.Population
from city as ci join country as co
on ci.ID = co.Capital
where lcase(co.Name) like lcase('united%');

-- 5
select co.Name,Capital,
ifnull(ci.Name,'수도없음') as '수도',
ifnull(ci.Population,'수도없음') as '수도'
from city as ci right outer join country as co
on ci.ID = co.Capital
where lcase(co.Name) like lcase('united%');

-- 6
select count(*)
from country join countrylanguage as c
on country.Code = c.CountryCode
where Percentage > all (select countrylanguage.Percentage
from countrylanguage
where CountryCode='che' and IsOfficial = 'T')
and IsOfficial = 'T';

-- 7
select language
from Countrylanguage
where CountryCode = (select Code
from country
where Name='south korea')
and IsOfficial='T';

-- 8
select country.Name,CountryCode,count(*)
from city join country
on country.Code = city.CountryCode
where CountryCode in (select Code
from country
where lcase(Name) like lcase('bo%'))
group by CountryCode;

-- 9
-- select country.Name,ci.CountryCode , ifnull(count(*),'단독') as '도시개수'
-- from city as ci right join country
-- on country.Code = ci.CountryCode
-- where CountryCode in (select Code
-- from country
-- where lcase(Name) like lcase('bo%'))
-- group by CountryCode;

-- 10
select CountryCode,Name,Population
from city
order by Population desc limit 1;

-- 11
select ct.Name,city.CountryCode,city.Name,city.Population
from city join (select Code as CountryCode ,Name from country ) ct 
using (CountryCode)
order by Population asc limit 1;

-- 12
select CountryCode,Name,Population
from city
where Population >(select Population
from city
where CountryCode = 'KOR' and Name='Seoul');

-- 13
select CountryCode ,language
from countrylanguage
where CountryCode in (select CountryCode from city where Name = 'San Miguel')
and IsOfficial = 'T';

-- 14
select CountryCode,max(Population)
from city
group by CountryCode;

-- 15
select distinct CountryCode,Name,Population
from city
group by CountryCode
order by CountryCode asc,Population desc;

-- 16 왜 239건이징
select distinct co.Code,co.Name,ci.Name,ci.Population
from city as ci join country as co
on ci.CountryCode = co.Code
group by ci.CountryCode
order by ci.CountryCode asc,Population desc;

-- 17
create view summary
as (select distinct co.Code,co.Name as co_name,ci.Name as ci_name,ci.Population
from city as ci join country as co
on ci.CountryCode = co.Code
group by ci.CountryCode
order by ci.CountryCode asc,Population desc);

select *
from summary;

-- 18
select Code,co_name,ci_name,Population
from summary
where Code = 'KOR';