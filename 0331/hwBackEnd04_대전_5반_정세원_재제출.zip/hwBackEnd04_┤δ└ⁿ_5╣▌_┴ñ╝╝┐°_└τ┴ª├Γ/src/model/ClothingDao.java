package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClothingDao {
	private Connection con = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	
	public List<ClothingDTO> selectAll(){
		try {
			con = DBUtil.makeConnection();
			String sql="SELECT SERIAL_NUMBER,CATEGORY,BRAND,PRICE FROM CLOTHING_TB";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			ArrayList<ClothingDTO> clothinglist = new ArrayList<>();
			while(rs.next()) {
				ClothingDTO clothing = new ClothingDTO();
				clothing.setSerial(rs.getString(1));
				clothing.setCategory(rs.getString(2));
				clothing.setBrand(rs.getString(3));
				clothing.setPrice(rs.getInt(4));
				
				clothinglist.add(clothing);
			}
			return clothinglist;
		
		}catch(SQLException e) {
			System.out.println("ado selectAll error");
			e.printStackTrace();
		}finally {
			DBUtil.close(con);
			DBUtil.close(pstmt);
			DBUtil.close(rs);
		}
		return null;
	}
	
	public int insert(ClothingDTO clothing){
		int result=0;
		try {
			con=DBUtil.makeConnection();
			String sql="INSERT INTO CLOTHING_TB(SERIAL_NUMBER,CATEGORY,BRAND,PRICE)" +"VALUES(?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, clothing.getSerial());
			pstmt.setString(2, clothing.getCategory());
			pstmt.setString(3, clothing.getBrand());
			pstmt.setInt(4, clothing.getPrice());
			result = pstmt.executeUpdate();
			
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(con);
			DBUtil.close(pstmt);
			DBUtil.close(rs);
			
		}
		return result;
	}
	
	public ClothingDTO selectClothing(String serial) {
		try {
			con=DBUtil.makeConnection();
			String sql="SELECT SERIAL_NUMBER,CATEGORY,BRAND,PRICE FROM CLOTHING_TB "+" WHERE SERIAL_NUMBER=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, serial);
			rs = pstmt.executeQuery();
			rs.next();
			
			ClothingDTO clothing = new ClothingDTO();
			clothing.setSerial(rs.getString(1));
			clothing.setCategory(rs.getString(2));
			clothing.setBrand(rs.getString(3));
			clothing.setPrice(rs.getInt(4));
			
			return clothing;
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(con);
			DBUtil.close(pstmt);
			DBUtil.close(rs);
		}
		return null;
	}
	
	public int delete(String serial) {
		int result=0;
		try {
			con = DBUtil.makeConnection();
			String sql = "DELETE FROM CLOTHING_TB "+" WHERE SERIAL_NUMBER=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, serial);
			result = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(con);
			DBUtil.close(pstmt);
			DBUtil.close(rs);
		}
		return result;
	}
}