<template>
  <div>
    <h1>게시판</h1>
    <table border="1">
      <tr>
        <td>글번호</td>
        <td>제목</td>
        <td>작성자</td>
        <td>작성일</td>
      </tr>
      <tr v-for="(b, index) in boardlist" :key="`${index}_boardlist.bList`">
        <td v-text="b.bnum"></td>
        <td>
          <router-link :to="`/board/read?bnum=${b.bnum}`">{{ b.btitle }}</router-link>
        </td>
        <td v-text="b.bwriter"></td>
        <td v-text="getFormatDate(b.bregdate)"></td>
      </tr>
    </table>
    <!-- <router-link to="/board/write">글쓰기</router-link> -->
    <button @click="movePage">글쓰기</button>
  </div>
</template>
<script>
// import http from "@/util/http-common2";
import { mapGetters } from "vuex";
import moment from "moment";
// import moment from
export default {
  computed: {
    ...mapGetters(["boardlist"]),
  },
  created() {
    this.$store.dispatch("getBoardList");
  },
  methods: {
    movePage() {
      this.$router.push("/board/write");
    },
    getFormatDate(regtime) {
      return moment(new Date(regtime)).format("YY.MM.DD HH:mm:ss");
    },
  },
};
</script>
