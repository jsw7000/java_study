package com.ssafy.rest.model.mapper;

import java.util.List;

import com.ssafy.rest.model.dto.Product;



public interface ProductMapper {
	public int insert(Product product);
	public Product select(String pCode);
	public List<Product> selectAll();
}
