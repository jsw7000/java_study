import Vue from "vue";
import VueRouter from "vue-router";
import Home from "../views/Home.vue";
import EmpList from "@/components/EmpList.vue";
import EmpInsert from "@/components/EmpInsert.vue";
import EmpDetail from "@/components/EmpDetail.vue";
import EmpModify from "@/components/EmpModify.vue";
import EmpDelete from "@/components/EmpDelete.vue";

Vue.use(VueRouter);

const routes = [
  // {
  //   path: "/",
  //   name: "index",
  //   component: Index,
  // },
  {
    path: "/",
    name: "Home",
    component: Home,
  },
  {
    path: "/emplist",
    name: "emplist",
    component: EmpList,
  },
  {
    path: "/empinsert",
    name: "empinsert",
    component: EmpInsert,
  },
  {
    path: "/empdetail",
    name: "empdetail",
    component: EmpDetail,
  },
  {
    path: "/empmodify",
    name: "empmodify",
    component: EmpModify,
  },
  {
    path: "/empdelete",
    name: "empdelete",
    component: EmpDelete,
  },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
