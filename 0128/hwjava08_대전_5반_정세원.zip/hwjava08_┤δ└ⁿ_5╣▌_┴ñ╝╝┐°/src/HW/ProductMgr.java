package HW;

import java.util.ArrayList;



public class ProductMgr implements IProductMgr{

	private ProductMgr() {
	}

	private static ProductMgr instance;

	public static ProductMgr getInstance() {
		if (instance == null)
			instance = new ProductMgr();
		return instance;
	}

	private ArrayList<Product> prod = new ArrayList<>();
	//private static int count = 0;

	// 상품저장
	public void add(Product p) throws DuplicateException{
		for(int i=0;i<prod.size();i++) {
			if(prod.get(i).getPnum()==p.getPnum()) {
				throw new DuplicateException(p.getPnum());
				}
		}
		prod.add(p);
	}

	// 저장된 상품List검색
	public ArrayList<Product> list() {
		ArrayList<Product> save = new ArrayList<>();
		save.addAll(prod);
		return save;
	}

	// 상품 번호로 검색
	@Override
	public Product list(int num) throws CodeNotFoundException{
		for(int i=0;i<prod.size();i++) {
			if(prod.get(i).getPnum()==num)
				return prod.get(i);
		}throw new CodeNotFoundException(num);
	}

	// 상품 번호로 삭제
	public void delete(int num) {
		for(int i=0;i<prod.size();i++) {
			if(prod.get(i).getPnum()==num) {
				prod.remove(i);

			}
		}
		//딜리트를 호출한 곳으로 던짐-> ProductTest의 case 4
		//이런 예외객체들을 던질 수 있는 명령어이다???
	}


	public ArrayList<Product> searchName(String name) {

		ArrayList<Product> result= new ArrayList<>();
		for (int i = 0; i < prod.size(); ++i) {
			if (prod.get(i).getPname().contains(name)) { 
				result.add(prod.get(i));
			}
		}
		return result; 
	}


	public ArrayList<TV> getTV() {

		ArrayList<TV> result = new ArrayList<>();
		for (int i = 0; i < prod.size(); ++i) {
			if (prod.get(i) instanceof TV) {	
				result.add((TV)prod.get(i));
			}
		}
		return result;
	} 
	
	public ArrayList<Refrigerator> getRefrigerator() {

		ArrayList<Refrigerator> result = new ArrayList<>();	

		for (int i = 0; i < prod.size(); ++i) {
			if (prod.get(i) instanceof Refrigerator) {
				result.add((Refrigerator)prod.get(i));
			}
		}
		return result;
	} 
	
	public ArrayList<TV> getTVInch() throws ProductNotFoundException{
		//50인치 이상의 TV 검색

		ArrayList<TV> result = new ArrayList<>();	

		for (int i = 0; i < prod.size(); ++i) {
			if (prod.get(i) instanceof TV) {
				if(((TV)prod.get(i)).getInch()>50)
					result.add((TV)prod.get(i));
			}
		}
		if(result.size()<=0)
			throw new ProductNotFoundException();
		return result;
	}
	
		public ArrayList<Refrigerator> getRefrigeratorVolume() throws ProductNotFoundException {
		//400L 이상의 냉장고 검색

		ArrayList<Refrigerator> result = new ArrayList<>();	

		for (int i = 0; i < prod.size(); ++i) {
			if (prod.get(i) instanceof Refrigerator) {
				if(((Refrigerator)prod.get(i)).getVolume()>400)
					result.add((Refrigerator)prod.get(i));
			}
		}	
		if(result.size()<=0)
			throw new ProductNotFoundException();
		return result;
	}
	
	public void editPrice(int num,int price) {
		for(int i=0;i<prod.size();i++) {
			if(prod.get(i).getPnum()==num){
				prod.get(i).setPrice(price);
			}
		}
	}
	
	public int getTotalPrice() {
		int total=0;
		for(int i=0;i<prod.size();i++) {
			total = total + prod.get(i).getPrice()*prod.get(i).getQuantity();
		}
		return total;
	}
	

}
