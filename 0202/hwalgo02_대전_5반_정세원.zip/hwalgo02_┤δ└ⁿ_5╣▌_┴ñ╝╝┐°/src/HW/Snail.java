package HW;

import java.util.Scanner;

public class Snail {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int T = sc.nextInt();
		for (int tc = 1; tc <= T; tc++) {
			int N = sc.nextInt();
			int[][] snail = new int[N][N];
			int count = 1;
			int i = 0, j = 0;
			// 베열
			int[] di= {0,1,0,-1}; //동남서북 방향
			int[] dj = {1,0,-1,0};
			int dir = 0;
			int ni,nj=0;
			while (count <= N * N) {
				
				snail[i][j]=count;

				ni=i+di[dir];
				nj=j+dj[dir];
				
				if(ni<0||ni>=N||nj<0||nj>=N||snail[ni][nj]!=0) { //다음 좌표가 범위를 벗어난다면
					dir = (++dir)%4; //방향전환
					ni=i+di[dir];
					nj=j+dj[dir];
				}
				
				
				count++;
				i=ni;
				j=nj;
				
			}
			
			System.out.println("#"+tc);
			for(int k=0;k<snail.length;k++) {
				for(int l=0;l<snail.length;l++) {
					System.out.print(snail[k][l]+" ");
				}
				System.out.println();
			}
		}
	}

}
