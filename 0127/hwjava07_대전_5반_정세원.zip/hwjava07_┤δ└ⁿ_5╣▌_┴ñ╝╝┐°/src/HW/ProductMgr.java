package HW;

import java.util.ArrayList;

public class ProductMgr implements IProductMgr{

	private ProductMgr() {
	}

	private static ProductMgr instance;

	public static ProductMgr getInstance() {
		if (instance == null)
			instance = new ProductMgr();
		return instance;
	}
	//상품정보(TV/냉장고)를 객체 배열을 활용하여 저장
	//상품정보 전체를 검색
	//상품번호로 상품 검색
	// 상품명으로 상품 검색(상품명 부분 검색 가능)
	// TV정보만 검색
	//Refrigerator 검색
	//상품번호로 상품을 삭제
	//전체 재고 상품 금액을 구하는 기능
	private ArrayList<Product> prod = new ArrayList<>();
	//private static int count = 0;

	// 상품저장
	public void add(Product p) {
		prod.add(p);
	}

	// 저장된 상품List검색
	public ArrayList<Product> list() {
		ArrayList<Product> save = new ArrayList<>();
		save.addAll(prod);
		return save;
	}

	// 상품 번호로 검색
	public Product list(int num) {
		for(int i=0;i<prod.size();i++) {
			if(prod.get(i).getPnum()==num)
				return prod.get(i);
		}
		return null;
	}

	// 상품 번호로 삭제
	public void delete(int num) {
		for(int i=0;i<prod.size();i++) {
			if(prod.get(i).getPnum()==num) {
				prod.remove(i);
			}
		}
	}


	public ArrayList<Product> searchName(String name) {

		ArrayList<Product> result= new ArrayList<>();
		for (int i = 0; i < prod.size(); ++i) {
			if (prod.get(i).getPname().contains(name)) { 
				result.add(prod.get(i));
			}
		}
		return result; 
	}


	public ArrayList<TV> getTV() {

		ArrayList<TV> result = new ArrayList<>();
		for (int i = 0; i < prod.size(); ++i) {
			if (prod.get(i) instanceof TV) {	
				result.add((TV)prod.get(i));
			}
		}
		return result;
	} 
	
	public ArrayList<Refrigerator> getRefrigerator() {

		ArrayList<Refrigerator> result = new ArrayList<>();	

		for (int i = 0; i < prod.size(); ++i) {
			if (prod.get(i) instanceof Refrigerator) {
				result.add((Refrigerator)prod.get(i));
			}
		}
		return result;
	} 
	
	public ArrayList<TV> getTVInch() {
		//50인치 이상의 TV 검색

		ArrayList<TV> result = new ArrayList<>();	

		for (int i = 0; i < prod.size(); ++i) {
			if (prod.get(i) instanceof TV) {
				if(((TV)prod.get(i)).getInch()>50)
					result.add((TV)prod.get(i));
			}
		}
		return result;
	}
	
	public ArrayList<Refrigerator> getRefrigeratorVolume() {
		//400L 이상의 냉장고 검색

		ArrayList<Refrigerator> result = new ArrayList<>();	

		for (int i = 0; i < prod.size(); ++i) {
			if (prod.get(i) instanceof Refrigerator) {
				if(((Refrigerator)prod.get(i)).getVolume()>400)
					result.add((Refrigerator)prod.get(i));
			}
		}
		return result;
	}
	
	public void editPrice(int num,int price) {
		for(int i=0;i<prod.size();i++) {
			if(prod.get(i).getPnum()==num){
				prod.get(i).setPrice(price);
			}
		}
	}
	
	public int getTotalPrice() {
		int total=0;
		for(int i=0;i<prod.size();i++) {
			total = total + prod.get(i).getPrice()*prod.get(i).getQuantity();
		}
		return total;
	}
	

}
