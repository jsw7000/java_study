<template>
  <div>
    <form>
      제목 : <input type="text" v-model="board.btitle" /><br />
      작성자 : <input type="text" v-model="board.bwriter" /><br />
      내용 : <textarea v-model="board.bcontent"></textarea><br />
      <button @click.prevent="boardSubmit">작성</button>
    </form>
    <router-link to="/board">목록</router-link>
  </div>
</template>
<script>
// import http from '@/util/http-common';
import { mapGetters } from "vuex";
export default {
  // name:'boardmodify',
  computed: {
    ...mapGetters(["board"]),
  },
  //   data() {
  //     return {
  //       board: {
  //         bnum: "",
  //         btitle: "",
  //         bwriter: "",
  //         bcontent: "",
  //         bregdate: "",
  //       },
  //     };
  //   },
  created() {
    let bnum = this.$route.query.bnum;
    // http.get(`/board?bnum=${bnum}`)
    // .then((resp)=>{
    //     this.article = resp.data;
    //     // console.log(list);
    // })
    this.$store.dispatch("getBoard", { bnum });
  },
  methods: {
    boardSubmit() {
      //     http.put(`/board?bnum=${this.board.bnum}`,{
      //         bnum:this.board.bnum,
      //         btitle:this.board.btitle,
      //         bwriter:this.board.bwriter,
      //         bcontent:this.board.bcontent,
      //         bregdate:this.board.bregdate,
      //     }).then((resp)=>{
      //     let msg ="게시물 수정에 실패하였습니다.";
      //     if(resp.data==="success"){
      //         msg = "게시물 수정이 완료되었습니다."
      //     }
      //     alert(msg);
      // })
      //     this.$router.push('/');
      this.$store.dispatch("updateBoard", this.board).then((resp) => {
        let msg = "게시물 수정에 실패하였습니다.";
        if (resp.data === "success") {
          msg = "게시물 수정이 완료되었습니다.";
        }
        alert(msg);
      });
      this.$router.push("/board/read?bnum=" + this.board.bnum);
    },
  },
};
</script>
