package model;

public class ClothingDTO {
	String serial;
	String category;
	String brand;
	int price;
	public ClothingDTO(String serial, String category, String brand, int price) {
		super();
		this.serial = serial;
		this.category = category;
		this.brand = brand;
		this.price = price;
	}
	
	
	public ClothingDTO() {
		super();
	}


	public String getSerial() {
		return serial;
	}


//	public void setSerial(String serial) {
//		this.serial = serial;
//	}

	public void setSerial(String serial) {
		this.serial = serial;
	}

	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public String getBrand() {
		return brand;
	}


	public void setBrand(String brand) {
		this.brand = brand;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "clothingDTO [serial=" + serial + ", category=" + category + ", brand=" + brand + ", price=" + price
				+ "]";
	}





	
	
}
