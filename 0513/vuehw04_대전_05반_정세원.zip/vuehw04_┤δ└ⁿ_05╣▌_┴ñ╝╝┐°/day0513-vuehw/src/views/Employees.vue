<template>
    <div class="employees">
        <EmpList msg="사원목록"/>
    </div>
</template>

<script>
import EmpList from '@/components/EmpList.vue';

export default {
    name : "EmpList",
    components:{
        EmpList,
    },
};
</script>