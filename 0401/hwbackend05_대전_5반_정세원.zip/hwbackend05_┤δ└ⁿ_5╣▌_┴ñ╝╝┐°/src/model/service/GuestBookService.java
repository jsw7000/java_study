package model.service;

import java.util.List;

import model.GuestBookDto;

public interface GuestBookService {
	
	List<GuestBookDto> listArticle(String key, String word) throws Exception;;
	
	void writeArticle(GuestBookDto guestBookDto) throws Exception;;
	
	
}
