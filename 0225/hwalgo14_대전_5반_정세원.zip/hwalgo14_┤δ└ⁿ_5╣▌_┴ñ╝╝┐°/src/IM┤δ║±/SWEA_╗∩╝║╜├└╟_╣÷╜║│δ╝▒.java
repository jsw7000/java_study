package IM대비;

import java.util.ArrayList;
import java.util.Scanner;

public class SWEA_삼성시의_버스노선 {

	public static void main(String[] args) {
		/*
		 * 1~5000번 번호
		 * 버스 노선 : N개
		 * i번째 버스노선은 번호가 Ai이상
		 * Bi이하인 모든 정류장만을 다니는 버스노선
		 * P개의 정류장->각 정류장엔 몇개의 노선이 다니는가?
		 * 
		 * */
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for(int tc=1;tc<=T;tc++) {
			int N = sc.nextInt();
			ArrayList<int[]> list = new ArrayList<>();
			
			for(int i=0;i<N;i++) {
				int[] arr = new int[2];
				arr[0]=sc.nextInt();
				arr[1]=sc.nextInt();
				list.add(arr);
//				System.out.println(Arrays.toString(list.get(i)));
			}
			
			int P = sc.nextInt();
			
			int[] station = new int[P];
			
			for(int i=0;i<P;i++) {
				station[i]=sc.nextInt();
			}
			
			int[] count = new int[P];
			int n=0;
			while(n!=list.size()) {
				int start=list.get(n)[0];
				int end =list.get(n)[1];
				for(int p=0;p<P;p++) {
					if(station[p]>=start&&station[p]<=end)
						count[p]++;
//					for(int i=start;i<=end;i++) {
//						if(station[p]==start)
//							count[p]++;
//					}
				}
				n++;
			}
			StringBuilder sb = new StringBuilder();
			sb.append("#"+tc);
			for(int i=0;i<P;i++) {
				sb.append(" "+count[i]);
			}
			
			System.out.println(sb);
			
		}
		
	}

}
