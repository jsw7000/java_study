package com.ssafy.product.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.product.dto.Product;
import com.ssafy.product.repository.ProductDao;

@Service
public class ProductService {
	
	@Autowired
	private ProductDao productDao;
	
	public List<Product> list() throws SQLException{
		return productDao.list();
	}


	public void insert(Product product) throws NoSuchFieldException,SQLException {
		if(product.getQuantity()==null)
			throw new NoSuchFieldException();
		else
			productDao.insert(product);
	}


	public Product select(String pCode) throws SQLException{
		// TODO Auto-generated method stub
		return productDao.select(pCode);
	}

}
