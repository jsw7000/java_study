package HW;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class 백준14889_스타트와링크 {
	static int N;
	static int[][] map;
	static boolean[] used;
//	static int[] result;
	static int MIN=Integer.MAX_VALUE;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N =sc.nextInt();
		map = new int[N+1][N+1];
		used= new boolean[N+1];
		result = new int[N/2];
		for(int i=1;i<=N;i++) {
			for(int j=1;j<=N;j++) {
				map[i][j]=sc.nextInt();
			}
		}
		
		select(1,0);
		System.out.println(MIN);
		
	}
	
	/* boolean[][] used=new boolean[N][N];
	 * result =new int[N/2] 배열도 만들어야함
	 * back(){
	 * cnt//뽑은 팀의 갯수
	 * if(cnt==N/2){
	 * 	뽑은 팀들의 점수 계산
	 * }
	 * 
	 * 
	 * for()
	 * }
	 * 
	 * 
	 * 
	 * 
	 * 
	 * */
	public static void select(int idx,int cnt) {
		if(cnt==N/2) {
			//뽑은 팀들의 점수 계산
			
			diff();
			return;
		}

		for(int i=idx;i<=N;i++) {
			if(!used[i]) {
//				result[cnt]=i;
				used[i] = true;
				select(i+1,cnt + 1);
				used[i]=false;
//				select(cnt);
			}
		}
	}
	static int[] result=new int[2];
	public static void diff() {
		int team_start=0;
		int team_link=0;
		
		for(int i=1;i<=N-1;i++) {
			for(int j=i;j<=N;j++) {
				if(used[i]==true&&used[j]==true) {
					team_start+=(map[i][j]+map[j][i]);
				}else if(used[i]==false&&used[j]==false) {
					team_link+=(map[i][j]+map[j][i]);
					
				}
			}
		}
		
		int dif=Math.abs(team_start-team_link);
		
		MIN=MIN>dif?dif:MIN;
			
	}
}
