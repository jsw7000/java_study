package com.ssafy.board.Mapper;

import org.apache.ibatis.annotations.Param;

import com.ssafy.board.dto.MemberDto;

public interface MemberMapper {
	public MemberDto login(@Param("userid") String userid,@Param("userpwd") String userpwd);
	
}
