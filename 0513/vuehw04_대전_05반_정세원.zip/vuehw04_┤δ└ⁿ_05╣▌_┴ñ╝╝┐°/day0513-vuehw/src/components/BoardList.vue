<template>
    <div>
        
    </div>
</template>
<script>
import http from '@/util/http-common2';
export default {
    name:'boardlist',
    data(){
        return{
            list:'',
        };
    },
    created(){
        http.get("/boardMain")
        .then((resp)=>{
            this.list = resp.data;
            console.log(list);
        })
    },
    methods:{

    },
}
</script>