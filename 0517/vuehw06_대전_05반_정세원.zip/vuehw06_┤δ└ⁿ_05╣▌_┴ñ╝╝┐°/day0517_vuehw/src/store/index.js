import Vue from "vue";
import Vuex from "vuex";
import http from "@/util/http-common";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    boardlist: [],
    board: [],
    comments: [],
  },
  mutations: {
    setBoardList(state, payload) {
      state.boardlist = payload;
    },
    setBoard(state, payload) {
      state.board = payload;
    },
    setComments(state, payload) {
      state.comments = payload;
    },
  },
  actions: {
    getBoardList(context) {
      http.get("/boardMain").then((resp) => {
        context.commit("setBoardList", resp.data["bList"]);
      });
    },
    getBoard(context, payload) {
      // console.log(payload.bnum);
      http.get("/board?bnum=" + payload.bnum).then((resp) => {
        context.commit("setBoard", resp.data);
      });
    },
    getComments() {},
    postBoard(context, payload) {
      return http.post("/board", payload);
    },
    // updateBoard(context, payload) {
    //   console.log(payload.bnum);
    //   return http
    //     .update(
    //       "/board?bnum=" +
    //       payload("bnum ") +
    //         "&btitle=" +
    //         payload.btitle +
    //         "&bwriter=" +
    //         payload.bwriter +
    //         "&bcontent=" +
    //         payload.bcontent +
    //         "&bregdate=" +
    //         payload.bregdate
    //     )
    //     .then((resp) => {
    //       alert(resp.data);
    //     });
    // },
    deleteBoard(context, payload) {
      return http.delete("/board?bnum=" + payload.bnum);
    },
  },
  getters: {
    boardlist(state) {
      return state.boardlist;
    },
    board(state) {
      return state.board;
    },
    comments(state) {
      return state.comments;
    },
  },
});
