

import java.util.Scanner;

public class ProductTest {

	public static void main(String[] args) {

		ProductMgr pmgr = ProductMgr.getInstance();

		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("1:상품추가,2:상품목록,3:상품검색,4:상품삭제,5:가격검색,-1:프로그램종료");
			int select = sc.nextInt();
			if (select == -1) {
				System.out.println("프로그램을 종료합니다.");
				break;
			}

			switch (select) {
			case 1:
				sc.nextLine();
				System.out.println("상품번호,상품이름,가격,수량");
				String[] input = sc.nextLine().split(",");
				pmgr.add(new Product(Integer.parseInt(input[0]), input[1], Integer.parseInt(input[2]),
						Integer.parseInt(input[3])));
				System.out.println("상품 저장 완료");
				break;
			case 2:
				for (Product p : pmgr.list())
					System.out.println(p);
				break;
			case 3:
				int pnumber = sc.nextInt();
				System.out.println(pmgr.list(pnumber).toString());
				break;
			case 4:
				int pRemove = sc.nextInt();
				pmgr.delete(pRemove);
				break;
			case 5:
				int pprice = sc.nextInt();
				for (Product p : pmgr.priceList(pprice))
					System.out.println(p);
				break;
			default:
				System.out.println("잘못된 입력입니다.");
			}

		}
		sc.close();
	}

}
