export default {
    template:
    `
    <div>
        <h2>사원정보</h2>
        <table border="1">
            <tr>
                <td>사원번호</td>
                <td>{{emp.id}}</td>
            </tr>
            <tr>
                <td>이름</td>
                <td>{{emp.name}}</td>
            </tr>
            <tr>
                <td>부서</td>
                <td>{{emp.deptName}}</td>
            </tr>
            <tr>
                <td>직책</td>
                <td>{{emp.title}}</td>
            </tr>
            <tr>
                <td>연봉</td>
                <td>{{emp.salary}}</td>
            </tr>
        </table>
        <a :href="'./delete.html?id='+emp.id">사원삭제</a>
        <a :href="'./update.html?id='+emp.id">사원정보수정</a><br>
        <a href="./list.html">사원목록</a>
    </div>
    `,
    data() {
        return {
            emp: '',
            id:'',
        }
    },
    created() {
        const param = new URL(document.location).searchParams;
        this.id = param.get("id");
        axios
            .get("http://localhost:9999/bootemp/employee?id="+this.id)
            .then((resp) => {
                this.emp = resp.data;
                console.log(this.emp.id);
        })
    },
}