package com.ssafy.hw.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.hw.dto.ProductDto;
import com.ssafy.hw.repository.ProductDao;

@Service
public class ProductService {
	
	@Autowired
	private ProductDao dao;
	
	public List<ProductDto> allList() throws SQLException {
		return dao.selectAll();
	}

	public void add(ProductDto product) throws SQLException {
		dao.add(product);
	}

}
