import Vue from "vue";
import VueRouter from "vue-router";
import Home from "../views/Home.vue";
import Board from "../views/Board.vue";
import BoardList from "@/components/BoardList.vue";
import BoardRead from "@/components/BoardRead.vue";
import BoardWrite from "@/components/BoardWrite.vue";
import BoardModify from "@/components/BoardModify.vue";
import BoardDelete from "@/components/BoardDelete.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "Home",
    component: Home,
  },
  {
    path: "/board",
    name: "board",
    component: Board,
    redirect: "/board/list",
    children: [
      {
        path: "list",
        name: "boardlist",
        component: BoardList,
      },
      {
        path: "read",
        name: "boardread",
        component: BoardRead,
      },
      {
        path: "write",
        name: "boardwrite",
        component: BoardWrite,
      },
      {
        path: "modify",
        name: "boardmodify",
        component: BoardModify,
      },
      {
        path: "delete",
        name: "boarddelete",
        component: BoardDelete,
      },
    ],
  },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
