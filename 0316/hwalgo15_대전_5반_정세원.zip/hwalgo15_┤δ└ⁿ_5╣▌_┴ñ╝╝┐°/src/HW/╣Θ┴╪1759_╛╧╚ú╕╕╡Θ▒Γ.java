package HW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class 백준1759_암호만들기 {
	static int L,C;
	static char[] arr;
	static char[] result;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine()," ");
		L=Integer.parseInt(st.nextToken());
		C=Integer.parseInt(st.nextToken());
		
		arr= new char[C];
		result=new char[L];
		st = new StringTokenizer(br.readLine()," ");
		for(int i=0;i<C;i++) {
			arr[i]=st.nextToken().charAt(0);
//			System.out.println(arr[i]);
		}
		Arrays.sort(arr);
		comb(0,0);
		
		
		
	}
	//모음을 담는 베열
	//자음을 담는 배열
	public static void comb(int start,int cnt) {
		if(cnt==L) {
			int m=0;
			int j=0;
			for(int i=0;i<result.length;i++) {
					switch(result[i]) {
					case 'a':
					case 'e':
					case 'o':
					case 'i':
					case 'u':
						m++;
						break;
					default:
						j++;
						break;
							
					}
			}
			if(m>=1&&j>=2) {
				for(int i=0;i<result.length;i++) {
					System.out.print(result[i]);
				}
				System.out.println();
			}
			return;
		}
		/*최소 2개의 자음과 최소 1개의 모음*/
		for(int i=start;i<C;i++) {
				result[cnt]=arr[i];
				comb(i+1,cnt+1);
		}
	}

}
