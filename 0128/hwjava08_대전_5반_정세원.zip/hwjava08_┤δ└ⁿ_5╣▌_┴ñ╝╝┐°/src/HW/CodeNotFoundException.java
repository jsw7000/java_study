package HW;

public class CodeNotFoundException extends Exception {

	private int pnum;
	public CodeNotFoundException(int pnum) {
		super(pnum+"상품번호는 존재하지 않습니다.");
		this.pnum=pnum;
	}
	public int getPnum() {
		return pnum;
	}
}
