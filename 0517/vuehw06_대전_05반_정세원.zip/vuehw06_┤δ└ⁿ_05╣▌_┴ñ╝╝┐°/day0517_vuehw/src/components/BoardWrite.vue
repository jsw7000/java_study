<template>
  <div>
    <form>
      제목 : <input type="text" v-model="board.btitle" /><br />
      작성자 : <input type="text" v-model="board.bwriter" /><br />
      내용 : <textarea v-model="board.bcontent"></textarea><br />
      <button @click="boardSubmit">작성</button>
    </form>
  </div>
</template>
<script>
export default {
  //   name: "boardwrite",
  data() {
    return {
      board: {
        btitle: "",
        bwriter: "",
        bcontent: "",
      },
    };
  },
  created() {},
  methods: {
    boardSubmit() {
      //   http
      //     .post("/board", {
      //       btitle: this.article.btitle,
      //       bwriter: this.article.bwriter,
      //       bcontent: this.article.bcontent,
      //     })
      //     .then((resp) => {
      //       let msg = "게시물 등록에 실패하였습니다.";
      //       if (resp.data === "success") {
      //         msg = "게시물 등록이 완료되었습니다.";
      //       }
      //       alert(msg);
      //     });

      this.$store.dispatch("postBoard", this.board).then((resp) => {
        let msg = "게시물 등록에 실패하였습니다.";
        if (resp.data === "success") {
          msg = "게시물 등록이 완료되었습니다.";
        }
        alert(msg);
      });
      this.$router.push("/board");
    },
  },
};
</script>
