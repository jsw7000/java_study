package HW;

import java.util.Scanner;

public class 백준2531_회전초밥 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int N=sc.nextInt();
		int d=sc.nextInt();
		int k=sc.nextInt();
		int c=sc.nextInt();
		int[] belt = new int[N];
		int[] sushi = new int[d+1];
		
		for(int i=0;i<N;i++) {
			belt[i]=sc.nextInt();
		}

		 int count = 0, max;
		 
	        for (int i = 0; i < k; i++) {
	            if (sushi[ belt[i] ] == 0) count++; // 처음 먹어보는 종류의 초밥이라면 카운트 + 1
	            sushi[ belt[i] ]++;
	        }
	        max = count;
	 
	        for (int i = 1; i < N; i++) {
	            if (max <= count) {
	                if (sushi[ c ] == 0) max = count + 1;
	                else max = count;
	            }
	 
	            sushi[ belt[i - 1] ]--;
	            if (sushi[ belt[i - 1] ] == 0) count--;
	 
	            if (sushi[ belt[(i + k - 1) % N]] == 0) count++;
	            sushi[ belt[(i + k - 1) % N]]++;
	        }
	 
		System.out.println(max);
		
	}

}
