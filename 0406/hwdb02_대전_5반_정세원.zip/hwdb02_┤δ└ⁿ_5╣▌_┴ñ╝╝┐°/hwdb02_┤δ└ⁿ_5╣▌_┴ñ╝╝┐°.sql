use scott;

select *
from dept;

select *
from emp;

/* 1. 부서위치가 CHICAGO인 모든 사원에 대해 
이름,업무,급여 출력하는 SQL을 작성하세요.*/

select ENAME,JOB,SAL
from emp natural join dept
where LOC='CHICAGO';

/*2. 부하직원이 없는 사원의 사원번호,이름,업무,부서번호
출력하는 SQL을 작성하세요.*/
select m.EMPNO,m.ENAME,m.JOB,m.DEPTNO
from emp as e left join emp as m
on e.MGR=m.EMPNO
where count(e.EMPNO) is null
group by m.EMPNO;

/*3. BLAKE와 같은 상사를 가진 사원의 
이름,업무,상사번호 출력하는 SQL을 작성하세요*/

select ENAME,JOB,MGR
from emp
where MGR = (select MGR
			from emp
			where ENAME='BLAKE');

/*4. 입사일이 가장 오래된 사람 5명을 검색하세요.*/
select ENAME,HIREDATE
from emp
order by HIREDATE asc limit 5;


/*5. JONES 의 부하 직원의 이름, 업무, 부서명을 검색하세요.*/
select ENAME,JOB,DNAME
from emp natural join dept
where MGR = (select EMPNO from emp where ENAME='JONES');
