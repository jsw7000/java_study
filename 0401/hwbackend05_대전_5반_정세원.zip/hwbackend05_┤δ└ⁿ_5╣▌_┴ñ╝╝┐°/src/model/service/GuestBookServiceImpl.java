package model.service;

import java.util.List;

import model.GuestBookDto;
import model.dao.GuestBookDaoImpl;

public class GuestBookServiceImpl implements GuestBookService{

	private GuestBookDaoImpl guestBookDao;
	
	public GuestBookServiceImpl() {
		guestBookDao = new GuestBookDaoImpl();
	}
	
	@Override
	public List<GuestBookDto> listArticle(String key, String word) throws Exception {
		key = key == null ? "" : key;
		word = word == null ? "" : word;
		return guestBookDao.listArticle(key,word);
	}
	
	@Override
	public void writeArticle(GuestBookDto guestBookDto) throws Exception{
		if(guestBookDto.getSubject()==null||guestBookDto.getContent()==null) {
			throw new Exception();
		}
		guestBookDao.writeArticle(guestBookDto);
	}

}
