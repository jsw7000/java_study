<template>
  <div>
    <h3>결과 : {{ msg }}</h3>
    <router-link to="/board">목록보기</router-link>
  </div>
</template>
<script>
// import http from "@/util/http-common";
export default {
  //   name: "boarddelete",
  data() {
    return {
      msg: "",
    };
  },
  created() {
    let bnum = this.$route.query.bnum;
    // http.delete(`/board?bnum=${bnum}`).then((resp) => {
    //   this.msg = resp.data;
    // });
    this.$store.dispatch("deleteBoard", { bnum }).then((resp) => {
      this.msg = resp.data;
    });
  },
};
</script>
