package HW;

import java.util.Scanner;

public class hwalgo03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for (int test_case = 1; test_case <= T; test_case++) {
			int N = sc.nextInt();
			int[][] fly = new int[N][N];
			int M = sc.nextInt();
			// int[][] kill = new int[M][M];

			for (int i = 0; i < fly.length; i++) {
				for (int j = 0; j < fly.length; j++)
					fly[i][j] = sc.nextInt();
			}

			int max = 0;
			for (int i = 0; i < fly.length; i++) {
				if (i + M - 1 < fly.length) {
					for (int j = 0; j < fly.length; j++) {
						int sum = 0;

						if (j + M - 1 < fly.length) {
							for (int k = 0; k < M; k++) {
								for (int l = 0; l < M; l++) {
									sum = sum + fly[i + k][j + l];

								}

							}
							max = (max < sum) ? sum : max;
						} else
							break;

					}
				} else
					break;
			}
			
			System.out.println("#"+test_case+" "+max);

		}
	}

}
