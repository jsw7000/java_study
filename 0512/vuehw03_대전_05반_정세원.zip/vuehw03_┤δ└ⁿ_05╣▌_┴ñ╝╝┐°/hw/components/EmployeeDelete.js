export default {
    template: `
    <div>
        <h3>삭제 결과 : {{result}}</h3>
        <a href="list.html">사원목록보기</a>
    </div>
    `,
    data() {
        return {
            result: '',
            id:'',
        }
    },
    created() {
        const param = new URL(document.location).searchParams;
        this.id = param.get("id");
        axios
            .delete("http://localhost:9999/bootemp/employee?id=" + this.id)
            .then((resp) => {
                this.result = resp.data;
                console.log(this.result);
            })
    },
}