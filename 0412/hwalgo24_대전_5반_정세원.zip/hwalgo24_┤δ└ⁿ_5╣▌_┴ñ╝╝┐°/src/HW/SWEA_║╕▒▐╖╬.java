package HW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

public class SWEA_보급로 {
	static int N,min;
	static int[][] map;
	static int[][] cost;
	static boolean[][] visited;
	static int[] di = {-1,1,0,0};
	static int[] dj = {0,0,-1,1};
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		/*
		 * 출발지 S에서 도착지G까지 가기 위한 도로 복구 작업(최단 시간)
		 * 도로가 파여진 깊이에 비례해서 복구 시간은 증가
		 * 출발지에서 도착지까지 가는 경로 중에 복구 시간이 가장 짧은 경로에 대한 총 복구 시간을 구하시오.
		 * 깊이가 1이라면 복구가 드는 시간은 1
		 * 
		 * 지도 n*n
		 * 출발지S : 좌상단 0,0
		 * 도착지G : 우하단 n-1,n-1
		 * 
		 * 이동경로는 상하좌우 방향 진행 가능
		 * di,dj
		 * 
		 * 전역 : minTime,N,map,visited
		 * 지도 정보에 각 칸마다 파여진 도로의 깊이가 주어짐. 현재 위치한 칸의 도로를 복구해야만 다른 곳으로 이동 가능
		 * boolean[][] visited필요
		 * 
		 * dfs(x,y,time)
		 * */
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int T = Integer.parseInt(br.readLine());
		for(int tc=1;tc<=T;tc++) {
			N= Integer.parseInt(br.readLine());
			map = new int[N][N];
			visited = new boolean[N][N];
//			min=Integer.MAX_VALUE;
			for(int i=0;i<N;i++) {
				String str = br.readLine();
				for(int j=0;j<N;j++) {
					map[i][j]= Integer.parseInt(str.substring(j,j+1));
				}
			}
			
//			visited[0][0]=true;
//			dfs(0,0,0);

			cost = new int[N][N];
			for(int i=0;i<N;i++)
				Arrays.fill(cost[i], Integer.MAX_VALUE);
			bfs();
			
			System.out.println("#"+tc+" "+cost[N-1][N-1]);
		}
		
	}
//	public static void dfs(int x,int y,int time) {
//		if(time>min) return;
//		if(x==N-1&&y==N-1) {
//			if(min>time)
//				min=time;
//			
//			return;
//		}
//		
//		
//		for(int d=0;d<4;d++) {
//			int ni = x+di[d];
//			int nj = y+dj[d];
//			if(ni>=0&&ni<N&&nj>=0&&nj<N&&!visited[ni][nj]) {
//				visited[ni][nj]=true;
//				dfs(ni,nj,time+map[ni][nj]);
//				visited[ni][nj]=false;
//			}
//			
//		}
//		
//		
//	}
	public static class Node{
		int x,y;

		public Node(int x, int y) {
			super();
			this.x = x;
			this.y = y;
		}
		
	}
	public static void bfs() {
		Queue<Node> queue = new LinkedList<>();
		queue.offer(new Node(0,0));
		visited[0][0]=true;
		cost[0][0]=0;
		
		while(!queue.isEmpty()) {
			
			Node now = queue.poll();
			int x=now.x;
			int y=now.y;
			
			
			for(int d=0;d<4;d++) {
				int ni = x+di[d];
				int nj = y+dj[d];
				if(ni>=0&&ni<N&&nj>=0&&nj<N) {
					if(!visited[ni][nj]) {
						queue.offer(new Node(ni,nj));
						cost[ni][nj]=cost[x][y]+map[ni][nj];
						visited[ni][nj]=true;
					}
					else if(cost[ni][nj]>cost[x][y]+map[ni][nj]) {
						cost[ni][nj]=cost[x][y]+map[ni][nj];
						queue.offer(new Node(ni,nj));
					}
				}
			}
		}
	}

}
