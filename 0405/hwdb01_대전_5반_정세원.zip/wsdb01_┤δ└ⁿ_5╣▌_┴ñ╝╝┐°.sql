
use world;

select @@autocommit;

select * from country;
-- 1
select count(*),count(IndepYear)
from country
where IndepYear is not null;

-- 2
select sum(LifeExpectancy) as 합계,round(avg(LifeExpectancy),2) as 평균
,max(LifeExpectancy) as 최대,min(LifeExpectancy) as 최소
from country;

-- 3
select continent, count(Name) as "국가 수" , sum(Population) as "인구 합"
from country
group by continent order by count(Name) desc;

-- 4
select continent, sum(SurfaceArea)
from country
group by continent order by sum(SurfaceArea) desc LIMIT 3;

-- 5
select continent,sum(GNP)
from country
where Population>=50000000
group by continent;

-- 6
select continent,sum(GNP)
from country
where Population>=50000000
group by continent having sum(GNP)>=5000000;

-- 7
select IndepYear,count(Name) as "독립 국가 수"
from country
where IndepYear is not null
group by IndepYear having count(Name)>=10;

-- 8번 문제 뭐라고? over 어쩌고..?
select continent, Name, GNP,avg(GNP) over(),avg(GNP) over (partition by continent)
from country;

-- 9 ㅁㄹ
-- insert into countrylanguage (countrycode,language,isOfficial,percentage)
-- values('AAA','외계어','F',10);

-- 10


-- 11


-- 12
update city
set population=population+population*0.1
where id= 2331;

select *
from city
where id=2331;

-- 13
-- delete
-- from country
-- where code='USA';

-- 14
rollback;

-- 15
create schema ssafy_ws_5th;

-- 16
use ssafy_ws_5th;
drop table if exists ssafy_ws_5th.user;

-- 17
create table user(
	id varchar(50) NOT NULL primary key,
    name varchar(100) NOT NULL default '익명',
    pass varchar(100) NOT NULL
);

-- 18
insert into user(id,pass,name) 
values
('hone','5678','홍싸피'),
('test','test','테스트');

-- 19
update user
set pass = concat(id,'@','테스트' )
where id='test';

select *
from user
where id='test';

-- 20
delete from user
where id='test';

select *
from user
where id='test';

commit;