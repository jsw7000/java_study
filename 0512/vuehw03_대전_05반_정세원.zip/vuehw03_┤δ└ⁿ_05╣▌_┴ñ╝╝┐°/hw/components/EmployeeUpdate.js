export default {
    template: `
    <div>
        <h2>사원정보수정</h2>
        <form>
            사원번호 : <input type="text" v-model="emp.id" disabled /><br>
            이름 : <input type="text" v-model="emp.name"><br>
            부서 : <input type="text" v-model="emp.deptName"><br>
            직책 : <input type="text" v-model="emp.title"><br>
            연봉 : <input type="number" v-model.number="emp.salary"><br>
            <button @click="empSubmit">등록</button>
        </form>
        <a href="./list.html">사원목록</a>
    </div>
    `,
    data() {
        return {
            emp: {
                id:'',
                name: '',
                deptName:'',
                title: '',
                salary:'',
            },
            id:'',
        }
    },
    created() {
        const param = new URL(document.location).searchParams;
        console.log(param);
        this.id = param.get("id");
        axios
            .get("http://localhost:9999/bootemp/employee?id="+this.id)
            .then((resp) => {
                this.emp = resp.data;
                console.log(this.emp.id);
        })
    },
    methods: {
        empSubmit() {
            // let form = new FormData();
            // form.append('id', this.emp.id);
            // form.append('name', this.emp.name);
            // form.append('deptName', this.emp.deptName);
            // form.append('title', this.emp.title);
            // form.append('salary', this.emp.salary);
            axios
                .put("http://localhost:9999/bootemp/employee?id=" + this.emp.id + "&name=" + this.emp.name + "&deptName=" + this.emp.deptName
                +"&title="+this.emp.title+"&salary="+this.emp.salary)
                .then((resp) => {
                    console.log(resp.data);
                    alert(resp.data);
                    // location.href = "./list.html";
                })
            // axios({
            //     method: 'put',
            //     url: "http://localhost:9999/bootemp/employee",
            //     data: {
            //         id:this.emp.id,
            //         name: this.emp.name,
            //         deptName: this.emp.deptName,
            //         title:this.emp.title,
            //         salary: this.emp.salary,
            //     },
            // })

        }
    },
}