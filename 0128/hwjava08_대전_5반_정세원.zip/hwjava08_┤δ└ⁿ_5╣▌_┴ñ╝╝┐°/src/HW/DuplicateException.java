package HW;

public class DuplicateException extends Exception {

	private int pnum;
	public DuplicateException(int pnum) {
		super(pnum+" 이미 존재하는 상품입니다.");
		this.pnum=pnum;
	}

	public int getPnum() {
		return pnum;
	}
}
