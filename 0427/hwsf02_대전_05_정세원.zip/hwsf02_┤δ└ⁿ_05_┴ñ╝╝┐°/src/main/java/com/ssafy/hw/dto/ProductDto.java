package com.ssafy.hw.dto;


public class ProductDto {
	private int pnum;
	private String pid;
	private String pname;
	private int price;
	private String pdescription;
	public ProductDto(int pnum, String pid, String pname, int price, String pdescription) {
		super();
		this.pnum = pnum;
		this.pid = pid;
		this.pname = pname;
		this.price = price;
		this.pdescription = pdescription;
	}
	public ProductDto() {
		super();
	}
	public int getPnum() {
		return pnum;
	}
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getPdescription() {
		return pdescription;
	}
	public void setPdescription(String pdescription) {
		this.pdescription = pdescription;
	}
	@Override
	public String toString() {
		return "ProductDao [pnum=" + pnum + ", pid=" + pid + ", pname=" + pname + ", price=" + price + ", pdescription="
				+ pdescription + "]";
	}
}
