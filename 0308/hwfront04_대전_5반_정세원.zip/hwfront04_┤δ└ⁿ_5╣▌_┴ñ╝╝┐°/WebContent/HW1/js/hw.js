let infix="";
$(function(){
	$('.select').click(function(){
		let val =$(this).text();
		
		
		if(val=="="){
			infix += val+eval(infix);
			$(".result>ol").append("<li>"+infix+"</li>")
			//$('.result').html(infix+"\n");
			infix="";
			$('input').val(infix);
			
			
		}else if(val=="CE"){
			infix="";
			$('input').val(infix);
		}else{
			infix+=val;
			$('input').val(infix);
		}
	});
});