<template>
    <div class="boardlist">
        <BoardList msg="게시판"/>
    </div>
</template>

<script>
import BoardList from '@/components/BoardList.vue';

export default {
    name : "BoardList",
    components:{
        BoardList,
    },
};
</script>