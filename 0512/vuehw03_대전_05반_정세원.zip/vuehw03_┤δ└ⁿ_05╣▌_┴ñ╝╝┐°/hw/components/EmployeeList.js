export default {
    template: `
    <div>
        <h2>사원목록</h2>
        <table border="1">
        <tr>
            <td>사원번호</td>
            <td>이름</td>
            <td>부서</td>
            <td>직책</td>
            <td>연봉</td>
        </tr>
        <tr v-for="emp in list">
            <td>{{emp.id}}</td>
            <td><a :href="'./detail.html?id=' + emp.id">{{emp.name}}</a></td>
            <td>{{emp.deptName}}</td>
            <td>{{emp.title}}</td>
            <td>{{emp.salary}}</td>
        </tr>
        </table>
        <a href="./insert.html">사원 추가</a>
    </div>
    `,
    data() {
        return {
            list:'',
        }
    },created() {
        axios
            .get("http://localhost:9999/bootemp/employeeList")
            .then((resp) => {
                this.list = resp.data;
                console.log(this.list);
        })
    },methods: {
        
    },

}