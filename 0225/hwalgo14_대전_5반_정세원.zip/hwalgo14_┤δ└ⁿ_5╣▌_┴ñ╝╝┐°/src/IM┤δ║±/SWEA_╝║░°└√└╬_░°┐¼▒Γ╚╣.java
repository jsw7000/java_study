package IM대비;

import java.util.Scanner;

public class SWEA_성공적인_공연기획 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		sc.nextLine();
		for (int tc = 1; tc <= T; tc++) {

			String str = sc.nextLine();
			int[] people = new int[str.length()];
			for (int i = 0; i < str.length(); i++) {
				people[i] = Integer.parseInt(str.substring(i, i + 1));
			}
//			System.out.println(Arrays.toString(people));

			int cnt = 0;
			int emp = 0;
			for (int i = 0; i < people.length; i++) {
				if (cnt >= i) {
					cnt += people[i];
				} else {
					int dif= i-cnt;
					emp += dif;
					cnt+=dif+people[i];
					
				}
			}

			System.out.println("#" + tc + " " + emp);
		}

	}

}
