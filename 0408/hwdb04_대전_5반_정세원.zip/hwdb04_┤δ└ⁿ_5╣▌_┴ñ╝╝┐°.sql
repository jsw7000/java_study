-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema hwdb04
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema hwdb04
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `hwdb04` DEFAULT CHARACTER SET utf8 ;
USE `hwdb04` ;

-- -----------------------------------------------------
-- Table `hwdb04`.`product`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hwdb04`.`product` ;

CREATE TABLE IF NOT EXISTS `hwdb04`.`product` (
  `productCode` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NULL,
  `price` INT NULL,
  PRIMARY KEY (`productCode`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hwdb04`.`user`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hwdb04`.`user` ;

CREATE TABLE IF NOT EXISTS `hwdb04`.`user` (
  `userid` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(10) NOT NULL,
  `address` VARCHAR(50) NOT NULL,
  `contact1` INT NOT NULL,
  `contact2` VARCHAR(45) NULL,
  PRIMARY KEY (`userid`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hwdb04`.`order`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hwdb04`.`order` ;

CREATE TABLE IF NOT EXISTS `hwdb04`.`order` (
  `orderid` INT NOT NULL AUTO_INCREMENT,
  `payCheck` TINYINT NULL DEFAULT 'F',
  `shippingCheck` TINYINT NULL DEFAULT 'F',
  `userid` INT NULL,
  PRIMARY KEY (`orderid`),
  INDEX `order_userid_fk_idx` (`userid` ASC) VISIBLE,
  CONSTRAINT `order_userid_fk`
    FOREIGN KEY (`userid`)
    REFERENCES `hwdb04`.`user` (`userid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `hwdb04`.`order_detatil`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `hwdb04`.`order_detatil` ;

CREATE TABLE IF NOT EXISTS `hwdb04`.`order_detatil` (
  `orderid` INT NOT NULL,
  `cnt` INT NULL,
  `productCode` INT NOT NULL,
  INDEX `order_detail_orderid_fk_idx` (`orderid` ASC) VISIBLE,
  INDEX `order_detail_productCode_fk_idx` (`productCode` ASC) VISIBLE,
  PRIMARY KEY (`orderid`, `productCode`),
  CONSTRAINT `order_detail_orderid_fk`
    FOREIGN KEY (`orderid`)
    REFERENCES `hwdb04`.`order` (`orderid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `order_detail_productCode_fk`
    FOREIGN KEY (`productCode`)
    REFERENCES `hwdb04`.`product` (`productCode`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
