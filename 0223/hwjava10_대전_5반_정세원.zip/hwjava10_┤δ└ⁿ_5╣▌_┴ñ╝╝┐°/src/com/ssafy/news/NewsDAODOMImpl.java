package com.ssafy.news;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.text.html.parser.DocumentParser;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import weather.Weather;
// 속보타이틀 목록
//타이틀 선택 시 그 속보 타이틀에 맞는 기사를 출력하는 프로젝트를 작성하여 보자.
public class NewsDAODOMImpl implements INewsDAO {
	List<News> list = new ArrayList<>();

	@Override
	public List<News> getNewsList(String url) {
		DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
		try{
			DocumentBuilder parser = f.newDocumentBuilder();
			Document dom = parser.parse(new URL(url).openConnection().getInputStream());
			Element root = dom.getDocumentElement();
			NodeList itemNodes = root.getElementsByTagName("item");
			
			
			for(int i=0;i<itemNodes.getLength();i++) {
				News news = new News();
				Node item = itemNodes.item(i);
				NodeList itemChilds = item.getChildNodes();
				
				
				for (int j = 0; j < itemChilds.getLength(); j++) { // data 태그 내부의 태그들 반복문으로 분석
					Node child = itemChilds.item(j);// title/description
					String tname = child.getNodeName();
					if (tname.equals("title")) { // 날짜태그
						news.setTitle(child.getFirstChild().getNodeValue());
					} else if (tname.equals("description")) { // 최저기온
						news.setDesc(child.getFirstChild().getNodeValue());
					} else if (tname.equals("url")) { // 최고기온
						news.setLink(child.getFirstChild().getNodeValue());
					} 
				} // data 태그 하나 다 봤네.
				list.add(news);
			}
		} catch (Exception e) {
			System.out.println("돔 파서 에러");
			e.printStackTrace();
		}
		return list;

	}
	@Override
	public News search(int index) {
		return null;

	}

	public void connectNews(String url) {

	}
}
//public class WeatherDomParser {
//	ArrayList<Weather> wList = new ArrayList<>();
//	String url = "http://www.weather.go.kr/weather/forecast/mid-term-rss3.jsp?stnId=108";
//
//	public ArrayList<Weather> getWeatherData() {
//		DocumentBuilderFactory f = DocumentBuilderFactory.newInstance(); // 걍 복붙하래
//		try {
//			DocumentBuilder parser = f.newDocumentBuilder();
//			Document dom = parser.parse(new URL(url).openConnection().getInputStream());
//			Element root = dom.getDocumentElement(); // 최상위 태그. 이 안에서 원하는 태그를 찾아 들어가야 함.
//			NodeList dataNodes = root.getElementsByTagName("data");// 데이터가 여러개니까~!
//
//			for (int i = 0; i < dataNodes.getLength(); i++) { // data 태그의 갯수만큼 반복됨
//				Weather weather = new Weather(); // weather 객체 생성
//				Node data = dataNodes.item(i); // dataNodes 중 i번째에 있는 놈/ data 태그 한 쌍
//
//				NodeList dataChilds = data.getChildNodes();// data 태그 내부에 있는 태그들도 노드들임.
//				/*
//				 * <data> <a>dd</a> <-요런 놈들도 노드들이란 의미 </data>
//				 */
//
//				for (int j = 0; j < dataChilds.getLength(); j++) { // data 태그 내부의 태그들 반복문으로 분석
//					Node child = dataChilds.item(j);// 최저기온, 최고기온 같은 가장 작은 태그들
//					String tname = child.getNodeName();
//
//					// Dom파서는 순서영향 안받음! Sax는 순서영향 O
//					if (tname.equals("tmEf")) { // 날짜태그
//						weather.setData(child.getFirstChild().getNodeValue());
//					} else if (tname.equals("tmn")) { // 최저기온
//						weather.setTmn(child.getFirstChild().getNodeValue());
//					} else if (tname.equals("tmx")) { // 최고기온
//						weather.setTmx(child.getFirstChild().getNodeValue());
//					} else if (tname.equals("wf")) { // 구름의 양
//						weather.setWf(child.getFirstChild().getNodeValue());
//					}
//				} // data 태그 하나 다 봤네.
//				wList.add(weather);
//			}
//		} catch (Exception e) {
//			System.out.println("돔 파서 에러");
//			e.printStackTrace();
//		}
//		return wList;
//	}
//}