<template>
    <tr>
        <td>{{id}}</td>
        <td>
            <router-link :to="`/empdetail?id=${id}`">
            {{name}}
            </router-link>
        </td>
        <td>{{deptName}}</td>
        <td>{{title}}</td>
        <td>{{salary}}</td>
    </tr>
</template>
<script>
export default {
    name : 'row',
    props:{
        id:{type:Number},
        name:{type:String},
        deptName:{type:String},
        title:{type:String},
        salary:{type:Number},
    }
}
</script>