package com.ssafy.hw06;

public class Refrigerator extends Product{
	
	String volume;
	int energy_level;
	
	public Refrigerator(int pnum, String pname, int price, int quantity,String volume,int enerygy_level) {
		super(pnum, pname, price, quantity);
		this.volume = volume;
		this.energy_level = enerygy_level;
		
	}

	public String getVolume() {
		return volume;
	}

	public void setVolume(String volume) {
		this.volume = volume;
	}

	public int getEnergy_level() {
		return energy_level;
	}

	public void setEnergy_level(int energy_level) {
		this.energy_level = energy_level;
	}
	
	@Override
	public String toString() {
		return "Refrigerator [ " +super.toString() +", 용량 : "+ volume + ", 에너지등급 : " + energy_level + "]";
	}

	
}
