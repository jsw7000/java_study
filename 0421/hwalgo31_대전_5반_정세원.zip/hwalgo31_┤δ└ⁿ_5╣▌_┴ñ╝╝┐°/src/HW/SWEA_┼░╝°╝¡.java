package HW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class SWEA_키순서 {
	static int N,M;
	static ArrayList<Integer>[] upList;
	static ArrayList<Integer>[] downList;
	static int[] result;

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int T = Integer.parseInt(br.readLine());
		for(int tc=1;tc<=T;tc++) {
			N = Integer.parseInt(br.readLine());
			M = Integer.parseInt(br.readLine());
			
			upList = new ArrayList[N+1];
			downList = new ArrayList[N+1];
			
			result = new int[N+1];
			
			
			for(int i=1;i<=N;i++) {
				upList[i] = new ArrayList<>();
				downList[i] = new ArrayList<>();
				
			}
			
			for(int i=0;i<M;i++) {
				StringTokenizer st = new StringTokenizer(br.readLine());
				int from = Integer.parseInt(st.nextToken());
				int to = Integer.parseInt(st.nextToken());
				upList[from].add(to);
				downList[to].add(from);
			
			}
			int cnt=0;
			for(int i=1;i<=N;i++) {
				if(bfs(i))
					cnt++;
			}
			System.out.println("#"+tc+" "+cnt);
			
		}
		
	}
	private static boolean bfs(int index) {
		
		Queue<Integer> queue = new LinkedList<Integer>();
		queue.offer(index);
		int count=-1;
		boolean[] visited = new boolean[N+1];
		while(!queue.isEmpty()) {
			int num = queue.poll();
			if(visited[num]) continue;
			visited[num]=true;
			count++;
			
			for(int next:upList[num]) {
				if(!visited[next])
					queue.offer(next);
			}
			
		}
		queue.clear();
		queue.offer(index);
		visited = new boolean[N+1];
		while(!queue.isEmpty()) {
			int num = queue.poll();
			if(visited[num]) continue;
			visited[num]=true;
			count++;
			
			for(int next:downList[num]) {
				if(!visited[next])
					queue.offer(next);
			}
		}
		
		if(count==N) 
			return true;
		else return false;
	}
}
