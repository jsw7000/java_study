package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.ClothingDTO;
import model.ClothingService;

@WebServlet("/clothing")
public class ClothingServlet extends HttpServlet{
	private ClothingService service = new ClothingService(); //차장 데리고 있다가 일 시켜야징

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String cmd = req.getParameter("cmd");
		String path="";
		
		if(cmd==null||cmd.equals("list")) {
			List<ClothingDTO> clothingList = service.getClothing();
			req.setAttribute("clothingList", clothingList);
			path="clothing_list.jsp";
		}else if(cmd.equals("addForm")) {
			path="clothing_add.jsp";
		}else if(cmd.equals("searchForm")) {
			path="clothing_search.jsp";
		}else if(cmd.equals("deleteForm")) {
			path="clothing_delete.jsp";
		}
		
		RequestDispatcher dispatcher = req.getRequestDispatcher(path);
		dispatcher.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		String cmd = req.getParameter("cmd");
		String path="";
		
		if(cmd.equals("add")) {
			String serial = req.getParameter("add_serial");
			String category = req.getParameter("add_category");
			String brand = req.getParameter("add_brand");
			String priceStr = req.getParameter("add_price");
			
			ClothingDTO clothing = new ClothingDTO(serial, category, brand, Integer.parseInt(priceStr));
			if(service.add(clothing)) {
				req.setAttribute("addResult", "success");
			}else {
				req.setAttribute("addResult", "fail");
			}
			
			path = "clothing_add_result.jsp";
		}else if(cmd.equals("search")) {
			String serial = req.getParameter("search_serial");
			ClothingDTO clothing = new ClothingDTO();
			clothing = service.search(serial);
			if(clothing!=null) {
				req.setAttribute("searchClothing", clothing);
//				req.setAttribute("searchResult", "success");
			}else {
//				req.setAttribute("searchResult", "fail");
			}
			path="clothing_search_result.jsp";
		}else if(cmd.equals("delete")) {
			String serial = req.getParameter("delete_serial");
			if(service.delete(serial)) {
				req.setAttribute("deleteResult", "success");
			}else {
				req.setAttribute("deleteResult", "fail");
			}
			path="clothing_delete_result.jsp";
		}
		RequestDispatcher dispatcher = req.getRequestDispatcher(path);
		dispatcher.forward(req, resp);
	}
	
}
