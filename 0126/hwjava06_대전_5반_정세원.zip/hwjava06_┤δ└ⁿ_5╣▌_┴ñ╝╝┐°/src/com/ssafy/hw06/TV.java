package com.ssafy.hw06;

public class TV extends Product {
	String display;
	int inch;

	public TV(int pnum, String pname, int price, int quantity, String display, int inch) {
		super(pnum, pname, price, quantity);
		this.display = display;
		this.inch = inch;

	}

	public String getDisplay() {
		return display;
	}

	public void setDisplay(String display) {
		this.display = display;
	}

	public int getInch() {
		return inch;
	}

	public void setInch(int inch) {
		this.inch = inch;
	}

	@Override
	public String toString() {
		return "TV [ " +super.toString() +", 디스플레이 : "+ display + ", 인치 : " + inch + "]";
	}

	
}
