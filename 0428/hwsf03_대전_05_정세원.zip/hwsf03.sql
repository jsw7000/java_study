create schema hwsf03;
use hwsf03;
#select * from comment_tb;
create table ssafy_member(
	userid varchar(16) primary key,	# 사용자 아이디
    username varchar(20) not null,		# 사용자 비밀번호
    userpwd varchar(16) not null,		# 사용자 이름
    email varchar(50),
    address varchar(100),
    joindate timestamp default now()
);
create table board_tb(
	bnum int primary key auto_increment,
	btitle varchar(100) not null,
	bwriter varchar(16),
	bregdate timestamp default now(),
	bcontent text not null,
    foreign key (bwriter) references ssafy_member(userid)
);
insert into ssafy_member(userid,username,userpwd,email,address) values ('ssafy','김싸피','ssafy','ssafy@ssafy.com','대전시 덕명동');
insert into ssafy_member(userid,username,userpwd,email,address) values ('admin','관리인','admin','admin@ssafy.com','여수시 여서동');
select * from ssafy_member;
commit;
create table comment_tb(
cnum int primary key auto_increment,
bnum int,
cwriter varchar(100) not null,
ccontent varchar(100) not null,
cregdate timestamp default now(),
 foreign key (cwriter) references ssafy_member(userid),
 foreign key (bnum) references board_tb(bnum)
);

insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
insert into board_tb(btitle,bwriter,bcontent) values ('오늘의 과제는?!','ssafy','끗~');
commit;

insert into comment_tb(bnum,cwriter,ccontent) values (1,'admin','끝냈냐?!');
insert into comment_tb(bnum,cwriter,ccontent) values (18,'admin','하나 더ㅋㅋ');
insert into comment_tb(bnum,cwriter,ccontent) values (19,'ssafy','무슨 내용을 웅앵'),(19,'admin','그러게말이여 웅앵');
commit;
