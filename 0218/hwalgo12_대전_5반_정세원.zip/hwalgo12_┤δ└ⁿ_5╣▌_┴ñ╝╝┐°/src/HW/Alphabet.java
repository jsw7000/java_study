package HW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Alphabet {
	static char[][] alpha;
	static int R, C;
	static boolean[][] used;
	static int Max;
	static StringBuilder sb = new StringBuilder();

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine(), " ");
		R = Integer.parseInt(st.nextToken());
		C = Integer.parseInt(st.nextToken());
		Max = 0;
		alpha = new char[R][C];
		used = new boolean[R][C];
		for (int i = 0; i < R; i++) {
			String str = br.readLine();
			for (int j = 0; j < C; j++) {
				alpha[i][j] = str.charAt(j);
			}
		}
		searchAlpha(0, 0, 0);
		System.out.println(Max);
	}

	static int[] di = { -1, 1, 0, 0 }; // 상하좌우
	static int[] dj = { 0, 0, -1, 1 };

	public static void searchAlpha(int r, int c, int cnt) {
		if (!isAvailable(r, c)) {
			Max = Max < cnt ? cnt : Max;
			return;
		}
		sb.append(alpha[r][c]);
		for (int d = 0; d < 4; d++) {
			int ni = r + di[d];
			int nj = c + dj[d];
			if (ni < R && nj < C && ni >= 0 && nj >= 0) {
				searchAlpha(ni, nj, cnt + 1);
			}
		}
		sb.setLength(sb.length() - 1);
	}

	public static boolean isAvailable(int r, int c) {
		for (int i = 0; i < sb.length(); i++) {
			if (sb.charAt(i) == alpha[r][c])
				return false;
		}
		return true;
	}

}
