package HW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class 백준9205_맥주마시면서걸어가기 {
//
	static final int INF=9999999;
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int T = Integer.parseInt(br.readLine());
		for(int tc=1;tc<=T;tc++) {
			
			int N = Integer.parseInt(br.readLine());
			
			int[][] pos = new int[N+2][2];
			for(int i=0;i<N+2;i++) {
				StringTokenizer st = new StringTokenizer(br.readLine()," ");
					int from = Integer.parseInt(st.nextToken());
					int to = Integer.parseInt(st.nextToken());
					
					pos[i][0]=from;
					pos[i][1]=to;
				}
			
			int end = N+1;
	
			int[] check = new int[N+2];
			Queue<Integer> queue = new LinkedList<Integer>();
			queue.add(0);
			boolean success = false;
			while(!queue.isEmpty()) {
				int current = queue.poll();
				if(current==end) {
					success=true;
					break;
				}
				
				for(int i=1;i<N+2;i++) {
					if(check[i]==0&Math.abs(pos[current][0] - pos[i][0]) + Math.abs(pos[current][1] - pos[i][1]) <= 1000) {
					queue.add(i);
                    check[i] = 1;
                    }
				}
			}
			 if(success){
	                System.out.println("happy");
	            }
	            else{
	                System.out.println("sad");
	            }

		}
			}


	
	}