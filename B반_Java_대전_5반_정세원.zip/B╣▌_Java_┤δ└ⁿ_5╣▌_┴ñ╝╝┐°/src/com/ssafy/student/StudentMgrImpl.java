package com.ssafy.student;

import java.util.Arrays;

public class StudentMgrImpl {

	
//	private StudentMgrImpl() { }
//	private static StudentMgrImpl Instance;
//	public static StudentMgrImpl getInstance() {
//		if(Instance==null)
//			Instance = new StudentMgrImpl();
//		return Instance;
//	}
	////////////////
	/** 교육생정보를 저장하기 위한 배열 */
	private Student[] students = new Student[100];
	/** 저장된 교육생 정보의 갯수를 기억하는 변수 */
	private int index = 0;

	/** 교육생 정보를 저장하는 메서드 */
	public void add(Student student) {

		// 구현 하세요.
		students[index]=student;
		index++;

	}

	/** 모든 교육생 정보를 리턴하는 메서드 */
	public Student[] search() {
		Student[] newStudents = new Student[index];

		// 구현 하세요.
		for(int i=0;i<index;i++) {
			newStudents[i]=students[i];
		}

		return newStudents;
	}

	/** 저장된 교육생정보 중 교육생번호를 검색하여 리턴하는 메서드 */
	public Student search(int studentNo) {

		// 구현 하세요.
		for(int i=0;i<index;i++) {
			if(students[i].getStudentNo()==studentNo)
				return students[i];
		}
		return null;
	}

	/** 저장된 교육생정보 중 교육생이름을 검색하여 리턴하는 메서드 */
	public Student[] search(String name) {
		Student[] newStudents = null;
		newStudents = new Student[index];
		// 구현 하세요.
		int count=0;
		for(int i=0;i<index;i++) {
			if(students[i].getName().equals(name)) {
				newStudents[count] = new Student();
				newStudents[count]=students[i];
				count++;
			}
		}
		if(count==0)
			return null;


		return newStudents;
	}

	/** 저장된 교육생정보 중 교육생번호를 검색하여 지역과 반번호를 수정하는 메서드 */
	public boolean update(int studentNo, String area, int classNo) {
		// 구현 하세요.
		for(int i=0;i<index;i++) {
			if(students[i].getStudentNo()==studentNo) {
				students[i].setArea(area);
				students[i].setClassNo(classNo);
				return true;
			}
		}
		return false;
	}

	/** 저장된 교육생정보 중 교육생번호를 검색하여 교육생을 삭제하는 메서드 */
	public boolean delete(int studentNo) {

		// 구현 하세요.
		for(int i=0;i<index;i++) {
			if(students[i].getStudentNo()==studentNo) {
				students[i]=students[index-1];
				students[index-1]=null;
				index--;
				return true;
			}
		}
		return false;
	}

}

