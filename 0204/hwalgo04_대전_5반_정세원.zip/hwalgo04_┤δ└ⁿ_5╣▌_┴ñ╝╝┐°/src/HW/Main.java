package HW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int N = Integer.parseInt(br.readLine());
		StringTokenizer st = new StringTokenizer(br.readLine()," ");
		int[] top = new int[N];
		int[] result = new int[N];
		
		for(int i=0;i<N;i++) { //top[] 원소 입력
			top[i]=Integer.parseInt(st.nextToken());
		}
		
		for(int i=0;i<N;i++) //result[] 초기회
			result[i]=0;
		
		for(int i=N-1;i>=0;i--) {
			for(int j=i-1;j>=0;j--) {
				if(top[j]>top[i]) {
					result[i]=j+1;
					break;
				}
			}
		}
		
		StringBuilder sb = new StringBuilder();
		for(int i=0;i<N;i++) {
			if(i==N-1) {
				sb.append(result[i]);
				break;
			}
			sb.append(result[i]+" ");
		}
		System.out.print(sb);
	}

}
