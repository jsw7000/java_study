package HW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class 백준1260_DFS와BFS {
	static int N,M;
	static boolean[][] adj;
	static boolean[] visit;
	static Queue<Integer> queue = new LinkedList<Integer>();
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine()," ");
		N=Integer.parseInt(st.nextToken());
		M=Integer.parseInt(st.nextToken());
		int V=Integer.parseInt(st.nextToken());
		
		adj = new boolean[N+1][N+1];
		visit = new boolean[N+1];
		for(int i=1;i<=M;i++) {
			st = new StringTokenizer(br.readLine()," ");
			int from = Integer.parseInt(st.nextToken());
			int to = Integer.parseInt(st.nextToken());
			adj[from][to]=true;
			adj[to][from]=true;
		}
		
		dfs(V);
		System.out.println();
		visit = new boolean[N+1];
		bfs(V);
		
	}
	static public void dfs(int start) {
		visit[start]=true;
//		queue.offer(start);
		
//		int current = queue.poll();
		System.out.print(start+" ");
		for(int i=1;i<=N;i++) {
			if(!visit[i]&&adj[start][i]&&adj[i][start])
				dfs(i);
		}
	}
	
	static public void bfs(int start) {
		visit[start]=true;
		queue.offer(start);
		while(!queue.isEmpty()) {
			int current=queue.poll();
			System.out.print(current+" ");
			for(int i=1;i<=N;i++) {
				if(!visit[i]&&adj[current][i]) {
					visit[i]=true;
					queue.add(i);
//					System.out.println(i);
//					if(adj[i][current]) {
//						
//					}
				}
			}
			
		}
	}

}
