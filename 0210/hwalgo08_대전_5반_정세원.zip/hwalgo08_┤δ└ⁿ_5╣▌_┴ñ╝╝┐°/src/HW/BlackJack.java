package HW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BlackJack {

	static int N, M, R = 3;
	static int[] card;
	static int[] result;
	static int MaxSum;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine(), " ");

		N = Integer.parseInt(st.nextToken());
		M = Integer.parseInt(st.nextToken());

		st = new StringTokenizer(br.readLine(), " ");

		card = new int[N];
		result = new int[R];
		MaxSum = 0;

		for (int i = 0; i < N; i++)
			card[i] = Integer.parseInt(st.nextToken());
		
		
		for(int i=0;i<N-2;i++) {
			for(int j=i+1;j<N-1;j++) {
				for(int k=j+1;k<N;k++)
					if(card[i]+card[j]+card[k]<=M)
						MaxSum = MaxSum<card[i]+card[j]+card[k]?card[i]+card[j]+card[k]:MaxSum;
			}
		}
//		comb(0, 0, 0);

		System.out.println(MaxSum);

	}
}

// 콤비네이션
//	static void comb(int start, int cnt, int sum) {
//
////		if(cnt==R) {
////			int sum=0;
////			for(int i=0;i<R;i++) {
////				sum+=result[i];
////			}
////			if(sum<=M)
////				MaxSum = MaxSum<sum?sum:MaxSum;
////			
////			return;
////		}
//		if (sum > M)
//			return;
//		if (sum <= M) {
//			if (cnt == R) {
//				MaxSum = MaxSum<sum?sum:MaxSum;
//				return;
//			}
//			
//
//			for (int i = start; i < N; i++) {
//				result[cnt] = card[i];
//				comb(i + 1, cnt + 1, sum + result[cnt]);
//				comb(i + 1, cnt, sum);
//			}
//		}
//	}

