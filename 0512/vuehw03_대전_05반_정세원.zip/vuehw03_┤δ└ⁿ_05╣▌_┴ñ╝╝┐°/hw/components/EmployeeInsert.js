export default {
    template: `
    <div>
        <h2>사원추가</h2>
        <form>
            이름 : <input type="text" v-model="newEmp.name"><br>
            부서 : <input type="text" v-model="newEmp.deptName"><br>
            직책 : <input type="text" v-model="newEmp.title"><br>
            연봉 : <input type="number" v-model.number="newEmp.salary"><br>
            <button @click="empSubmit">등록</button>
        </form>
        <a href="./list.html">사원목록</a>
    </div>
    `,
    data() {
        return {
            newEmp: {
                name: '',
                deptName:'',
                title: '',
                salary:'',
            },
        }
    },
    methods: {
        empSubmit() {
            axios({
                method: 'post',
                url: "http://localhost:9999/bootemp/employee",
                data: {
                    name: this.newEmp.name,
                    deptName: this.newEmp.deptName,
                    title:this.newEmp.title,
                    salary: this.newEmp.salary,
                },
            })
            
            alert("등록이 완료되었습니다.");
            // 목록 페이지로 이동하기
        }
    },
}