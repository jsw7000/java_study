package HW;

import java.util.Scanner;

public class Princess {
	static int N=9,R=7;
	static int[] numbers=new int[N];
	static int[] result = new int[R];
//	static int Sum;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		for(int i=0;i<N;i++)
			numbers[i] = sc.nextInt();
		
		comb(0,0);
		
	}
	public static void comb(int start,int cnt) {
		if(cnt==R) {
			int sum=0;
			for(int i=0;i<R;i++) {
				sum+=result[i];
			}
			
			if(sum==100) {
				for(int i=0;i<R;i++)
					System.out.println(result[i]);
			}
			
			return;
		}
		
		for(int i=start;i<N;i++) {
			result[cnt] = numbers[i];
			comb(i+1,cnt+1);
			comb(i+1,cnt);
		}
	}
}
