package com.ssafy.hw.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.ssafy.hw.dto.ProductDto;

@Repository
public class ProductDao {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	private DBUtil util = DBUtil.getInstance();
	
	public List<ProductDto> selectAll() throws SQLException{
		ArrayList<ProductDto> list = new ArrayList<ProductDto>();
		
		try {
			conn = util.makeConnection();
			String sql = "select pnum,pid,pname,price,pdescription from product_tb ";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				ProductDto product = new ProductDto();
				product.setPnum(rs.getInt(1));
				product.setPid(rs.getString(2));
				product.setPname(rs.getString(3));
				product.setPrice(rs.getInt(4));
				product.setPdescription(rs.getString(5));
				
				list.add(product);
			}
			
		} finally {
			util.close(conn,pstmt,rs);
		}
		return list;
	}
	public void add(ProductDto product) throws SQLException{
		try {
			conn = util.makeConnection();
			String sql = "insert into product_tb(pid,pname,price,pdescription) "
			+ "values(?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, product.getPid());
			pstmt.setString(2, product.getPname());
			pstmt.setInt(3, product.getPrice());
			pstmt.setString(4, product.getPdescription());
			
			pstmt.executeUpdate();
			
		} finally {
			util.close(conn,pstmt);
		}
		
	}
	
	
	
}
