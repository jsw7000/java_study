package com.ssafy.hw.controller;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.hw.dto.ProductDto;
import com.ssafy.hw.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	private ProductService pservice;
	
	@GetMapping(value="/productList")
	public ModelAndView productList() throws SQLException{
		ModelAndView mav = new ModelAndView("product/list");
		
		mav.addObject("pList", pservice.allList());
		return mav;
	}
	@GetMapping(value="/productAdd")
	public String prodcutAdd() {
		return "product/addForm";
	}
	
	@PostMapping(value="/productAdd")
	public String productAdd(ProductDto product) throws SQLException{
		pservice.add(product);
		return "product/result";
	}
	
}
