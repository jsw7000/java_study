$(function(){
	var n=0;
	const arr =[];
	var timer = setInterval(function() {
		let num;
		do{
			num = Math.floor(Math.random()*45)+1;
		}while($.inArray(num,arr)!=-1)
		arr.push(num);
		$('#target').append('<span>'+num+'</span>');
		if(arr.length==6){
			clearInterval(timer);}
	}, 1000)
})