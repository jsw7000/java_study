package HW;

import java.util.HashSet;
import java.util.Scanner;

public class SWEA_창용마을 {
	static int N,M;
	static int[] people;
	static void make() {
		for(int i=1;i<=N;i++) {
			people[i] = i;
		}
	}
	static void union(int a,int b) {
		int aRoot = findSet(a);
		int bRoot = findSet(b);
		
		if(aRoot!=bRoot)
			people[bRoot]=aRoot;
	}
	static int findSet(int a) {
		if(people[a]==a) {return a;}
		else {
			return people[a]=findSet(people[a]);
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for(int tc=1;tc<=T;tc++) {
			HashSet<Integer> set = new HashSet<>();
			N = sc.nextInt();
			M=sc.nextInt();
			people = new int[N+1];
			make();
			
			for(int i=0;i<M;i++) {
				int p1 = sc.nextInt();
				int p2 = sc.nextInt();
				
				union(p1,p2);
			}
			
			
			for(int i=1;i<=N;i++) {
				set.add(findSet(i));
			}
			
			System.out.println("#"+tc+" "+set.size());
		}
	}

}
