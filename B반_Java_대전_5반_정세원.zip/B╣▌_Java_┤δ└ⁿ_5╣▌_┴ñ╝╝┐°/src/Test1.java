/*
Test1.java : 자판기
 */

public class Test1 {

	public static void main(String[] args) {
		int price_sum=2530;//상품금액
		int pay=10000; //투입금액
		String charge = String.valueOf(pay-price_sum);
		int[] money = new int[4];

		System.out.println("투입금액 : " +pay+"원");
		System.out.println("상품금액 : " + price_sum+"원");
		System.out.println("거스름돈 : " + charge+"원");
		System.out.println("------------------");
		for(int i=0;i<charge.length();i++){
			money[i]=Integer.parseInt(charge.substring(i, i+1));
		}

		int thousand=0;
		int five_hundred=0;
		int one_hundred=0;
		int fifty=0;
		int ten=0;

		if(money[0]!=0) {
			thousand=money[0];
			money[0]=0;
		}
		if(money[1]/5==1) {
			five_hundred++;
			money[1]=money[1]-5;
			one_hundred=money[1];
		}
		if(money[2]/5==1) {
			fifty++;
			money[2]=money[2]-5;
			ten=money[2];
		}


		System.out.println("1000원 : "+thousand+"장");
		System.out.println("500원 : "+five_hundred+"개");
		System.out.println("100원 : "+one_hundred+"개");
		System.out.println("50원 : "+fifty+"개");
		System.out.println("10원 : "+ten+"개");
	}

}