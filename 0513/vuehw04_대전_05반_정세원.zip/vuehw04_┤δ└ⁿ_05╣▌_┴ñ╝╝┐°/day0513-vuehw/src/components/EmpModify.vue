<template>
    <div>
        <h2>사원정보수정</h2>
        <form>
            사원번호 : <input type="text" v-model="emp.id" disabled /><br>
            이름 : <input type="text" v-model="emp.name"><br>
            부서 : <input type="text" v-model="emp.deptName"><br>
            직책 : <input type="text" v-model="emp.title"><br>
            연봉 : <input type="number" v-model.number="emp.salary"><br>
            <button @click="empSubmit">등록</button>
        </form>
        <router-link to="/emplist">사원목록</router-link>
    </div>
</template>
<script>
import http from '@/util/http-common';
export default {
    name:'modify',
    data(){
        return{
            emp:{
                id:'',
                name:'',
                deptName:'',
                title:'',
                salary:'',
            },
        };
    },
    created(){
        this.emp.id=this.$route.query.id;
        console.log(this.emp.id);
        http.get(`/employee?id=${this.emp.id}`)
        .then((resp)=>{
            this.emp = resp.data;
        })
        
    },
    methods:{
        empSubmit(){
            http.put("employee?id=" + this.emp.id + "&name=" + this.emp.name + "&deptName=" + this.emp.deptName
                +"&title="+this.emp.title+"&salary="+this.emp.salary)
        //     {
        //     id:this.emp.id,
        //     name:this.emp.name,
        //     deptName:this.emp.deptName,
        //     title:this.emp.title,
        //     salary:this.emp.salary,
        // })
        .then((resp)=>{
            let msg = "수정 중 오류가 발생했습니다.";
            if(resp.data==="success"){
                msg = "수정 완료되었습니다.";
            }

            alert(msg);
            // this.$router.push("/emplist");
        })
        .catch(()=>{
            alert('수정시 에러가 발생하였습니다.');
            })
            this.$router.push(`/empdetail?id=${this.emp.id}`);
        }
    }
}
</script>