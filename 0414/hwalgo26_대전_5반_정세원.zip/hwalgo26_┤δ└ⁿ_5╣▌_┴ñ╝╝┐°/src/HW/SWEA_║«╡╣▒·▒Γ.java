package HW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class SWEA_벽돌깨기 {
	static int N,W,H;
	static int[] di = {-1,1,0,0};
	static int[] dj = {0,0,-1,1};
	static int min;
	static class Stone{
		int x,y,value;

		public Stone(int x, int y, int value) {
			super();
			this.x = x;
			this.y = y;
			this.value = value;
		}
		
	}
	public static void main(String[] args) throws NumberFormatException, IOException {

		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int T = Integer.parseInt(br.readLine());
		for(int tc=1;tc<=T;tc++) {
			StringTokenizer st = new StringTokenizer(br.readLine()," ");
			N = Integer.parseInt(st.nextToken());
			W = Integer.parseInt(st.nextToken());
			H = Integer.parseInt(st.nextToken());
			int[][] map = new int[H][W];
//			top = new int[W]; //열마다 top의 index를 저장할 배열
			min = Integer.MAX_VALUE;
			
			for(int i=0;i<H;i++) {
				st = new StringTokenizer(br.readLine()," ");
				for(int j=0;j<W;j++) {
					map[i][j]=Integer.parseInt(st.nextToken());
				}
			}
//			getTop();
			
//			int[][] copy = new int[H][W];
//			
//			for(int i=0;i<H;i++) {
//				for(int j=0;j<W;j++) {
//					copy[i][j]=map[i][j];
//				}
//			}
			
			dfs(0,map);
			System.out.println("#"+tc+" "+min);
		}
		
	}
	public static void dfs(int cnt,int[][] map) { //순열
		int ans=countStone(map);
		if(ans==0) {
			min=0;
			return;
		}
		if(cnt==N) {
//			System.out.println("--------------");
//			for(int i=0;i<H;i++)
//				System.out.println(Arrays.toString(map[i]));

			min = min>ans?ans:min;
			return;
		}

//		System.out.println("--------------");
//		for(int i=0;i<H;i++)
//			System.out.println(Arrays.toString(map[i]));
		for(int j=0;j<W;j++) {
			int i = 0;
			while(i < H) {
				if(map[i][j] != 0) break;
				i++;
			}
			
			if(i == H) continue;
			int[][] copy = copyArr(map);
			
			Queue<Stone> queue = new LinkedList<>();
			queue.add(new Stone(i,j,copy[i][j]));
			copy[i][j]=0;
			
			while(!queue.isEmpty()) {
				Stone stone = queue.poll();
				int nowi = stone.x;
				int nowj = stone.y;
				int nowValue = stone.value;
				
					for(int d=0;d<4;d++) {
						int count=0;
						int ni = nowi;
						int nj = nowj;
						while(count!=nowValue-1) {
							ni += di[d];
							nj += dj[d];
							if(ni>=H||ni<0||nj>=W||nj<0) break;
							if(copy[ni][nj]!=0) {
//								System.out.println(copy[ni][nj]+"왔니?");
								queue.add(new Stone(ni,nj,copy[ni][nj]));
								copy[ni][nj]=0;
							}
							count++;
						}
					}

			}
	
			dropStone(copy);
			dfs(cnt+1,copy);
			
			
		}
	}
	public static int countStone(int[][] map) {
		int count=0;
		for(int i=0;i<H;i++) {
			for(int j=0;j<W;j++) {
				if(map[i][j]>0) count++;
			}
		}
		return count;
	}
	public static void dropStone(int[][] copy) {
//		System.out.println("--------------");
//		for(int i=0;i<H;i++)
//			System.out.println(Arrays.toString(copy[i]));
		for(int j=0;j<W;j++) {
			ArrayList<Integer> list = new ArrayList<>();
			for(int i=H-1;i>=0;i--) {
				if(copy[i][j]>0) {
					list.add(copy[i][j]);
				}
			}
			
			int size=0;
			for(int i=H-1;i>=H-list.size();i--) {
				copy[i][j]=list.get(size);
				size++;
			}
			for(int i=H-list.size()-1;i>=0;i--) {
				copy[i][j]=0;
			}
//			System.out.println("--------------");
//			for(int i=0;i<H;i++)
//				System.out.println(Arrays.toString(copy[i]));
			
		}
		
	}
	static int[][] copyArr(int[][] arr) {
		int[][] newArr = new int[H][W];
		for(int i=0; i<H; i++) {
			for(int j=0; j<W; j++) {
				newArr[i][j] = arr[i][j];
			}
		}
		return newArr;
	}
}
