<template>
    <div>
        <h2>사원추가</h2>
        <form>
            이름 : <input type="text" v-model="emp.name"><br>
            부서 : <input type="text" v-model="emp.deptName"><br>
            직책 : <input type="text" v-model="emp.title"><br>
            연봉 : <input type="number" v-model.number="emp.salary"><br>
            <button @click="empSubmit">등록</button>
        </form>
        <router-link to="/emplist">사원목록</router-link>
    </div>
</template>
<script>
    import http from '@/util/http-common';
export default {
    name:'insert',
    data() {
        return {
            emp:{
                name:'',
                deptName:'',
                title:'',
                salary:'',
            },
        }
    },
    methods:{
        empSubmit() {
            http.post('/employee',{
                name:this.emp.name,
                deptName:this.emp.deptName,
                title:this.emp.title,
                salary:this.emp.salary,
                }).then((resp)=>{
                    let msg = "등록에 실패하였습니다.";
                    if(resp.data==="success"){
                        msg = "등록이 완료되었습니다.";
                    }
                    
                    alert(msg);
                    // this.moveList(); 왜 이동이 안될까ㅜㅜㅜㅜㅜ

            })
            .catch(()=>{
                alert('등록시 에러가 발생하였습니다.');
            })
            
            // 목록 페이지로 이동하기
            this.$router.push('/emplist');
        },
        moveList(){
            this.$router.push('/emplist');
        }
    }
}
</script>