package com.ssafy.product.controller;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	private ProductService pservice;
	
	@RequestMapping("/")
	public String index() {
		return "index";
	}
	
	@GetMapping("/list")
	public ModelAndView getAllProducts() {
		ModelAndView mav = new ModelAndView("product/list");
		try {
			mav.addObject("productList", pservice.list());
		}  catch (SQLException e) {
			mav.setViewName("error/500");
			e.printStackTrace();
		}
		return mav;
	}
	
	@PostMapping("/product")
	public ModelAndView addProduct(Boolean check,Product product) {
		ModelAndView mav = new ModelAndView();
		if(!check) {
			mav.setViewName("regist");
			mav.addObject("msg", "중복된 코드를 가진 상품이 존재합니다.");
		}else {
			try {
				pservice.insert(product);
				mav.addObject("msg","상품 등록에 성공하였습니다.");
				mav.setViewName("regist");
			}catch (NoSuchFieldException | SQLException e) {
				e.printStackTrace();
				mav.setViewName("error/500");
			}
		}
		return mav;
	}
	
	@GetMapping("/registForm")
	public String insert() throws SQLException{
		return "product/regist";
	}
	
	@GetMapping("/pcodeCheck")
	@ResponseBody
	public String pcodeCheck(String pCode) throws SQLException{
		if(pservice.select(pCode)!=null) {
			return "no";
		}else {
			return "yes";
		}
	}
	
}
