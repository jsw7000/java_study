

public class Product {
	private int pnum;
	private String pname;
	private int price;
	private int quantity;
	
	public Product() {}
	public Product(int pnum, String pname, int price, int quantity) {
		this.pnum = pnum;
		this.pname = pname;
		this.price = price;
		this.quantity = quantity;
	}
	public int getPnum() {
		return pnum;
	}
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String toString() {
		return "Product [상품번호: " + pnum + ", 상품이름: " + pname + ", 가격: " + price + ", 수량: " + quantity + "]";
	}
	
}
