package com.ssafy.product.mapper;

import java.util.List;
import com.ssafy.product.dto.Product;

public interface ProductMapper {
//	public SqlSessionTemplate template;
	
	public List<Product> list();
	public int insert(Product product);
	public Product select(String pCode);

}
