package com.ssafy.product.repository;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import com.ssafy.product.dto.Product;
import com.ssafy.product.mapper.ProductMapper;

@Repository
public class ProductDao {
	private SqlSessionTemplate template;
	
	public void insert(Product product) {
		template.getMapper(ProductMapper.class).insert(product);
	}

	public Product select(String pCode) {
		return template.getMapper(ProductMapper.class).select(pCode);
	}

	public List<Product> list() {
		return template.getMapper(ProductMapper.class).list();
	}

}
