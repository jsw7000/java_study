package HW;

import java.util.Scanner;

public class Switch {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
		int[] sw = new int[size];
		for (int i = 0; i < sw.length; i++) {
			sw[i] = sc.nextInt();
		}
		int TC = sc.nextInt();
		for (int tc = 0; tc < TC; tc++) {
			int gender = sc.nextInt();
			int integer = sc.nextInt();
			if (gender == 1) {// 남학생
				for (int i = 0; i < sw.length; i++) {
					if ((i + 1) % integer == 0) {
						if (sw[i] == 0) {
							sw[i] = 1;
						} else if (sw[i] == 1) {
							sw[i] = 0;
						}

					}
				}

			} else if (gender == 2) {// 여학생
				int cnt = 1;
				boolean[] used = new boolean[size];
				int index = integer - 1;
				used[index] = true;

				while (index - cnt >= 0 && index + cnt < sw.length) {
					if (sw[index - cnt] == sw[index + cnt]) {
						used[index - cnt] = true;
						used[index + cnt] = true;
					}
					if (sw[index - cnt] != sw[index + cnt])
						break;
					cnt++;
				}
				for (int i = 0; i < used.length; i++) {
					if (used[i] == true) {
						if (sw[i] == 0) {
							sw[i] = 1;
						} else if (sw[i] == 1) {
							sw[i] = 0;
						}
					}
				}
			}

		}
		for (int i = 0; i < sw.length; i++) {
			System.out.print(sw[i]+" ");
		}
	}
}
