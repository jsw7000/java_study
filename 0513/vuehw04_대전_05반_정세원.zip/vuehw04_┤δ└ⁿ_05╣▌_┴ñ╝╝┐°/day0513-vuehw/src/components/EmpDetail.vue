<template>
    <div>
        <h2>사원정보</h2>
        <table border="1">
            <tr>
                <td>사원번호</td>
                <td>{{emp.id}}</td>
            </tr>
            <tr>
                <td>이름</td>
                <td>{{emp.name}}</td>
            </tr>
            <tr>
                <td>부서</td>
                <td>{{emp.deptName}}</td>
            </tr>
            <tr>
                <td>직책</td>
                <td>{{emp.title}}</td>
            </tr>
            <tr>
                <td>연봉</td>
                <td>{{emp.salary}}</td>
            </tr>
        </table>
        <router-link :to="`/empmodify?id=${emp.id}`">사원정보수정</router-link> | 
        <router-link :to="`/empdelete?id=${emp.id}`">사원정보삭제</router-link> | 
        <router-link :to="`/emplist`">사원목록</router-link>
        <!-- <a :href="'./delete.html?id='+emp.id">사원삭제</a>
        <a :href="'./update.html?id='+emp.id">사원정보수정</a><br>
        <a href="./list.html">사원목록</a> -->
    </div>
</template>
<script>
import http from '@/util/http-common';
// import Detail from '@/components/Detail.vue';
export default {
    name:'detail',
    components:{

    },
    data:function(){
        return{
            emp:'',
        };
    },
    created(){
        http.get(`/employee?id=${this.$route.query.id}`).then((resp) => {
                this.emp = resp.data;
                console.log(this.emp.id);
        });
    },
}
</script>