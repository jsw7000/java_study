package HW;

import java.util.ArrayList;

public interface IProductMgr {
	
	void add(Product p) throws DuplicateException; //상품정보를 저장
	ArrayList<Product> list(); //상품정보 전체를 검색하는 기능
	Product list(int num) throws CodeNotFoundException; // 상품번호로 상품을 검색하는 기능
	void delete(int num); //상품번호로 상품을 삭제
	ArrayList<Product> searchName(String name); //상품명으로 상품을 검색하는 기능(상품명 부분 검색 가능)
	ArrayList<TV> getTV(); //TV만 검색
	ArrayList<Refrigerator> getRefrigerator(); //냉장고만 검색
	ArrayList<TV> getTVInch() throws ProductNotFoundException; //50인치 이상의 TV 검색
	ArrayList<Refrigerator> getRefrigeratorVolume() throws ProductNotFoundException; //400L 이상의 냉장고 검색
	void editPrice(int num,int price);//상품번호와 가격을 입력받아 상품 가격을 변경할 수 있는 기능
	int getTotalPrice();
	
}
