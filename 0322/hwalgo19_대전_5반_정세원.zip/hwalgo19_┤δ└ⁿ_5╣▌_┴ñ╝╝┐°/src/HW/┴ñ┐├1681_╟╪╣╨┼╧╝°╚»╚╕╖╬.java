package HW;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class 정올1681_해밀턴순환회로 {
	static int N;
	static int min;
	static int[][] map;
//	static int[] route;
	static ArrayList<Integer> list =new ArrayList<>();
	static boolean[] visited;
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		N = sc.nextInt();
		min = Integer.MAX_VALUE;
		map = new int[N][N];
		visited = new boolean[N];
//		route = new int[N];
		
		for(int i=0;i<N;i++) {
			for(int j=0;j<N;j++) {
				map[i][j] = sc.nextInt();
			}
		}
		list.add(0);
		visited[0]=true;
		dfs(0,0);
		System.out.println(min);
	}
	public static void dfs(int cnt,int cost) {
		int current = list.get(list.size()-1);
		if(cost>=min) return;
		if(cnt==N-1) {
			if ( map[current][0] !=0 ) {
				int end = list.get(list.size()-1);
				cost+= map[end][0];
//				System.out.println(Arrays.toString(list.toArray()));
				min=min>cost?cost:min;
			}

			return;
		}
		for(int i=0;i<N;i++) {
			if(!visited[i]&&current!=i&&map[current][i]!=0) {
				visited[i]=true;
				list.add(i);
				dfs(cnt+1,cost+map[current][i]);
				list.remove(list.size()-1);
				visited[i]=false;
			}

		}
		

	}

}
