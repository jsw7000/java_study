package HW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Friends {


	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine(), " ");

		int N = Integer.parseInt(st.nextToken()); //사람 수
		int M = Integer.parseInt(st.nextToken()); // 한 사람이 공을 받는 횟수 제한
		int L = Integer.parseInt(st.nextToken()); // 몇번째 사람에게 던질건지
		
		int[] friend = new int[N];
		
		for(int i=0;i<N;i++) {
			friend[i]=0;
		}
		
		
		
		/*홀수이면 오른쪽에서 L번째 사람에게 던지기
		짝수이면 왼쪽에서 L번째 사람에게 던지기
		친구들을 담을 LinkedList<class> list
		
		class friend - n,count;
		각자 받은 횟수를 저장할 count배열[N];
		
		while(link가 빌때까지)
		*/
		//
		int index=0;
		int cnt=0;
		while(true){
			friend[index]++;
			if(friend[index]==M)
				break;
			if(friend[index]%2==1) {//공가진 애 count가 홀수라면?!
				for(int i=0;i<L;i++) { //L번째 사람에게 공던지기

					index++;
					if(index>=friend.length)
						index=0;
					
					if(i==L-1) {
						break;
					}
				
			}
		}else if(friend[index]%2==0) {//공가진 애 count가 짝수라면?!
				for(int i=0;i<L;i++) { //L번째 사람에게 공던지기

					index--;
					if(index<0)
						index=friend.length-1;
					
					if(i==L-1) {
						break;
					}
			}
		}
			cnt++;
	}
		System.out.println(cnt);
		
	}

}
