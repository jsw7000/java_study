package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.GuestBookDto;
import model.dao.GuestBookDaoImpl;
import model.service.GuestBookServiceImpl;

@WebServlet("/Main")
public class MainController extends HttpServlet{
	private GuestBookServiceImpl guestBookService;
	
	public MainController() {
		guestBookService = new GuestBookServiceImpl();
	}
	
	String path = "/index.jsp";
	
	private void process(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		request.setCharacterEncoding("utf-8");
		
		String root = request.getContextPath();
		String act = request.getParameter("act");
		if(act.equals("list")) {
			listArticle(request,response);
		}else if(act.equals("write")) {
			writeArticle(request,response);
		}else if(act.equals("mvwrite")) {
			response.sendRedirect(root+"/guestbook/guestbook_write.jsp");
		}
	}
	

	private void listArticle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String key = request.getParameter("key");
		String word = request.getParameter("word");
		
		try {
			List<GuestBookDto> list = guestBookService.listArticle(key,word);
			request.setAttribute("articles", list);
			path = "/guestbook/guestbook_list.jsp";
		}catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "글목록을 얻어오는데 실패하였습니다.");
			path = "/error/error.jsp";
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);
		
	}
	private void writeArticle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		GuestBookDto guestBookDto = new GuestBookDto();
		guestBookDto.setUserid("ssafy");
		guestBookDto.setSubject(request.getParameter("subject"));
		guestBookDto.setContent(request.getParameter("content"));
		try {
			guestBookService.writeArticle(guestBookDto);
			path= "/guestbook/guestbook_write_result.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "글작성 중 문제가 발생했습니다.");
			path = "/error/error500.jsp";
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}
}
