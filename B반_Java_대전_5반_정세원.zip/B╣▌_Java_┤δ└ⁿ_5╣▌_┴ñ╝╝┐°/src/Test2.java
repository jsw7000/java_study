import java.util.Scanner;

/*
Test2.java : 팀원 평균

[테스트케이스]

6
5 50 50 70 80 100
7 100 95 90 80 70 60 50
3 70 90 80
3 70 90 81
9 100 99 98 97 96 95 94 93 91
4 75 70 83 68

*/

public class Test2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int TC=sc.nextInt();
		int tc=0;
		
		while(tc<TC) {
			
			int member = sc.nextInt();
//			if(member<1||member>1000)
//			{
//				System.out.println("1과 1000 사이의 수를 입력해주세요.");
//			}
			int[] score = new int[member];//점수 저장 배열
			int sum=0;
			//팀원 수=
			
			for(int i=0;i<score.length;i++) {
				score[i]=sc.nextInt();
				//점수는 0보다 크거나 같고 100보다 작거나 같다.
				sum=sum+score[i];
			}
			
			double avg=sum/score.length;
			int count=0;

			for(int i=0;i<score.length;i++) {
				if(avg<score[i])
					count++;
			}
			
			double per = ((double)count/(double)member)*100;
			
			//System.out.println(per);
			
			
			System.out.printf("#%d %.3f",tc,per);
			System.out.print("%");
			System.out.println();
			tc++;
		}

		sc.close();
	}
	
}