package model;

import java.util.List;

public class ClothingService {
	public ClothingDao dao = new ClothingDao();
	
	public List<ClothingDTO> getClothing(){
		return dao.selectAll();
	}
	public boolean add(ClothingDTO clothing) {
		if(clothing.getSerial()==null||clothing.getPrice()>10000000) {
			return false;
		}
		if(dao.insert(clothing)==1) {
			return true;
		}
		return false;
	}
	public ClothingDTO search(String serial) {
		
		return dao.selectClothing(serial);
		
		
	}
	
	public boolean delete(String serial) {
		if(dao.delete(serial)==1) {
			return true;
		}
		return false;
	}
	
}
